-- phpMyAdmin SQL Dump
-- version 3.5.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Aug 29, 2013 at 06:22 PM
-- Server version: 5.5.24-log
-- PHP Version: 5.3.13

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `slidewiki`
--

-- --------------------------------------------------------

--
-- Table structure for table `answers`
--

CREATE TABLE IF NOT EXISTS `answers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `question_id` int(11) NOT NULL,
  `answer` text COLLATE utf8_unicode_ci NOT NULL,
  `is_right` enum('yes','no') COLLATE utf8_unicode_ci NOT NULL,
  `explanation` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `brand`
--

CREATE TABLE IF NOT EXISTS `brand` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `deck_revision_id` int(11) NOT NULL,
  `image` tinytext,
  `url` tinytext,
  `description` tinytext,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `brand`
--

INSERT INTO `brand` (`id`, `deck_revision_id`, `image`, `url`, `description`) VALUES
(2, 56, 'http://aksw.org/files/logos/General/AKSW_Logo_rgb.png', 'http://aksw.org', 'This presentation is brought to you by  AKSW Research Group.'),
(3, 964, 'http://www.wsmx.org/images/wwa_STI.jpg', 'http://www.sti2.at/', 'This presentation is brought to you by STI2 - Semantic Technologies Institute International'),
(4, 1002, 'http://www.wsmx.org/images/wwa_STI.jpg', 'http://www.sti2.at/', 'This presentation is brought to you by STI2 - Semantic Technologies Institute International');

-- --------------------------------------------------------

--
-- Table structure for table `comment`
--

CREATE TABLE IF NOT EXISTS `comment` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `item_type` enum('slide','deck','comment','user') COLLATE utf8_unicode_ci NOT NULL,
  `item_id` int(10) unsigned NOT NULL,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `text` text COLLATE utf8_unicode_ci NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `item_type` (`item_type`,`item_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `deck`
--

CREATE TABLE IF NOT EXISTS `deck` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `user_id` int(10) unsigned NOT NULL,
  `description` tinytext CHARACTER SET utf8,
  `language` tinytext COLLATE utf8_unicode_ci,
  `translated_from` int(11) DEFAULT NULL,
  `translated_from_revision` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=10 ;

--
-- Dumping data for table `deck`
--

INSERT INTO `deck` (`id`, `timestamp`, `user_id`, `description`, `language`, `translated_from`, `translated_from_revision`) VALUES
(1, '2013-08-29 17:44:33', 1, '', 'en-English', NULL, NULL),
(2, '2013-08-29 17:44:57', 1, '', 'en-English', NULL, NULL),
(3, '2013-08-29 17:45:16', 1, '', 'en-English', NULL, NULL),
(4, '2013-08-29 17:45:43', 1, '', 'en-English', NULL, NULL),
(5, '2013-08-29 17:46:04', 1, '', 'en-English', NULL, NULL),
(6, '2013-08-29 17:46:23', 1, '', 'en-English', NULL, NULL),
(7, '2013-08-29 17:46:43', 1, '', 'en-English', NULL, NULL),
(8, '2013-08-29 17:47:04', 1, '', 'en-English', NULL, NULL),
(9, '2013-08-29 17:47:29', 1, '', 'en-English', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `deck_content`
--

CREATE TABLE IF NOT EXISTS `deck_content` (
  `deck_revision_id` int(10) unsigned NOT NULL,
  `item_type` enum('deck','slide') COLLATE utf8_unicode_ci NOT NULL,
  `item_id` int(11) NOT NULL,
  `position` int(11) NOT NULL,
  UNIQUE KEY `deck_revision_id` (`deck_revision_id`,`position`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `deck_content`
--

INSERT INTO `deck_content` (`deck_revision_id`, `item_type`, `item_id`, `position`) VALUES
(1, 'slide', 2, 1),
(1, 'slide', 3, 2),
(1, 'slide', 4, 3),
(1, 'slide', 5, 4),
(1, 'slide', 6, 5),
(2, 'slide', 8, 1),
(2, 'slide', 9, 2),
(3, 'slide', 11, 1),
(3, 'slide', 12, 2),
(3, 'slide', 67, 3),
(3, 'slide', 14, 4),
(3, 'slide', 15, 5),
(3, 'slide', 66, 6),
(4, 'slide', 18, 1),
(4, 'slide', 19, 2),
(4, 'slide', 20, 3),
(4, 'slide', 21, 4),
(4, 'slide', 22, 5),
(5, 'slide', 24, 1),
(5, 'slide', 25, 2),
(5, 'slide', 26, 3),
(6, 'slide', 28, 1),
(6, 'slide', 29, 2),
(6, 'slide', 30, 3),
(6, 'slide', 31, 4),
(6, 'slide', 32, 5),
(6, 'slide', 33, 6),
(6, 'slide', 34, 7),
(6, 'slide', 35, 8),
(6, 'slide', 36, 9),
(6, 'slide', 68, 10),
(7, 'slide', 39, 1),
(7, 'slide', 69, 2),
(7, 'slide', 70, 3),
(8, 'slide', 43, 1),
(8, 'slide', 44, 2),
(8, 'slide', 45, 3),
(8, 'slide', 46, 4),
(8, 'slide', 47, 5),
(8, 'slide', 48, 6),
(8, 'slide', 49, 7),
(8, 'slide', 50, 8),
(8, 'slide', 51, 9),
(8, 'slide', 52, 10),
(9, 'slide', 54, 1),
(9, 'slide', 64, 2),
(9, 'slide', 56, 3),
(9, 'slide', 57, 12),
(9, 'slide', 58, 13),
(9, 'slide', 59, 14),
(9, 'slide', 60, 15),
(9, 'slide', 71, 16),
(9, 'slide', 72, 17),
(9, 'slide', 63, 18),
(9, 'deck', 4, 11),
(9, 'deck', 1, 10),
(9, 'deck', 2, 8),
(9, 'deck', 5, 9),
(9, 'deck', 6, 7),
(9, 'deck', 7, 6),
(9, 'deck', 3, 5),
(9, 'deck', 8, 4);

-- --------------------------------------------------------

--
-- Table structure for table `deck_revision`
--

CREATE TABLE IF NOT EXISTS `deck_revision` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `deck_id` int(10) unsigned NOT NULL,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `user_id` int(10) unsigned NOT NULL,
  `based_on` int(10) unsigned DEFAULT NULL,
  `popularity` int(11) NOT NULL DEFAULT '0',
  `default_theme` int(11) NOT NULL DEFAULT '1',
  `default_transition` int(11) DEFAULT '2',
  `comment` text COLLATE utf8_unicode_ci,
  `abstract` text COLLATE utf8_unicode_ci,
  `footer_text` tinytext COLLATE utf8_unicode_ci,
  `license` enum('CC0','CC BY','CC BY-SA') COLLATE utf8_unicode_ci NOT NULL DEFAULT 'CC BY',
  `is_featured` tinyint(4) NOT NULL,
  `priority` int(11) DEFAULT '0',
  `visibility` tinyint(1) NOT NULL DEFAULT '1',
  `translation_status` enum('in_progress','translated') COLLATE utf8_unicode_ci DEFAULT NULL,
  `translated_from_revision` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  FULLTEXT KEY `title` (`title`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=10 ;

--
-- Dumping data for table `deck_revision`
--

INSERT INTO `deck_revision` (`id`, `deck_id`, `title`, `timestamp`, `user_id`, `based_on`, `popularity`, `default_theme`, `default_transition`, `comment`, `abstract`, `footer_text`, `license`, `is_featured`, `priority`, `visibility`, `translation_status`, `translated_from_revision`) VALUES
(1, 1, 'Benefits', '2013-08-29 17:44:33', 1, NULL, 0, 2, 4, NULL, '', '', 'CC BY', 0, 0, 0, NULL, NULL),
(2, 2, 'Best practices', '2013-08-29 17:44:57', 1, NULL, 0, 2, 4, NULL, '', '', 'CC BY', 0, 0, 0, NULL, NULL),
(3, 3, 'Collaborative authoring of presentations', '2013-08-29 17:45:16', 1, NULL, 0, 2, 4, NULL, '', '', 'CC BY', 0, 0, 0, NULL, NULL),
(4, 4, 'Get involved!', '2013-08-29 17:45:43', 1, NULL, 0, 2, 4, NULL, '', '', 'CC BY', 0, 0, 0, NULL, NULL),
(5, 5, 'Implementation', '2013-08-29 17:46:04', 1, NULL, 0, 2, 4, NULL, '', '', 'CC BY', 0, 0, 0, NULL, NULL),
(6, 6, 'Other features', '2013-08-29 17:46:23', 1, NULL, 0, 2, 4, NULL, '', '', 'CC BY', 0, 0, 0, NULL, NULL),
(7, 7, 'Questionnaires', '2013-08-29 17:46:43', 1, NULL, 0, 2, 4, NULL, '', '', 'CC BY', 0, 0, 0, NULL, NULL),
(8, 8, 'Slide editing', '2013-08-29 17:47:04', 1, NULL, 0, 2, 4, NULL, '', '', 'CC BY', 0, 0, 0, NULL, NULL),
(9, 9, 'Documentation', '2013-08-29 17:47:29', 1, NULL, 0, 2, 4, NULL, '', '', 'CC BY', 0, 0, 1, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `doubtful`
--

CREATE TABLE IF NOT EXISTS `doubtful` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `question_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `comment` text COLLATE utf8_unicode_ci,
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `impress_transition`
--

CREATE TABLE IF NOT EXISTS `impress_transition` (
  `user_id` int(11) NOT NULL,
  `deck_revision_id` int(11) NOT NULL,
  `slide_position` int(11) NOT NULL,
  `css` text,
  UNIQUE KEY `transition` (`user_id`,`deck_revision_id`,`slide_position`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `media`
--

CREATE TABLE IF NOT EXISTS `media` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `type` text COLLATE utf8_unicode_ci NOT NULL,
  `URI` text COLLATE utf8_unicode_ci NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `title` text COLLATE utf8_unicode_ci NOT NULL,
  `original_width` int(10) unsigned NOT NULL,
  `original_height` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=20 ;

--
-- Dumping data for table `media`
--

INSERT INTO `media` (`id`, `user_id`, `type`, `URI`, `timestamp`, `title`, `original_width`, `original_height`) VALUES
(1, 1, 'img', './upload/media/images/1/1.png', '2013-08-29 17:45:16', '1869', 0, 0),
(2, 1, 'img', './upload/media/images/1/2.png', '2013-08-29 17:45:16', '5524', 0, 0),
(3, 1, 'img', './upload/media/images/1/3.png', '2013-08-29 17:46:23', '5526', 0, 0),
(4, 1, 'img', './upload/media/images/1/4.png', '2013-08-29 17:46:43', '3925', 0, 0),
(5, 1, 'img', './upload/media/images/1/5.png', '2013-08-29 17:46:43', '3926', 0, 0),
(6, 1, 'img', './upload/media/images/1/6.png', '2013-08-29 17:47:29', '2196', 0, 0),
(7, 1, 'img', './upload/media/images/1/7.jpg', '2013-08-29 17:47:29', '2195', 0, 0),
(8, 1, 'img', './upload/media/images/1/8.png', '2013-08-29 17:47:29', '2194', 0, 0),
(9, 1, 'img', './upload/media/images/1/9.jpg', '2013-08-29 17:47:29', '7361', 0, 0),
(10, 1, 'img', './upload/media/images/1/10.png', '2013-08-29 17:47:29', '7363', 0, 0),
(11, 1, 'img', './upload/media/images/1/11.jpg', '2013-08-29 17:47:29', '7364', 0, 0),
(12, 1, 'img', './upload/media/images/1/12.png', '2013-08-29 17:47:29', '1869', 0, 0),
(13, 1, 'img', './upload/media/images/1/13.png', '2013-08-29 17:47:29', '5524', 0, 0),
(14, 1, 'img', './upload/media/images/1/14.png', '2013-08-29 17:47:29', '3925', 0, 0),
(15, 1, 'img', './upload/media/images/1/15.png', '2013-08-29 17:47:29', '3926', 0, 0),
(16, 1, 'img', './upload/media/images/1/16.png', '2013-08-29 17:47:29', '5526', 0, 0),
(17, 1, 'img', './upload/media/images/1/17.png', '2013-08-29 17:47:29', '3997', 0, 0),
(18, 1, 'img', './upload/media/images/1/18.gif', '2013-08-29 17:47:29', '4001', 0, 0),
(19, 1, 'img', './upload/media/images/1/19.png', '2013-08-29 17:47:29', '4000', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `media_relations`
--

CREATE TABLE IF NOT EXISTS `media_relations` (
  `media_id` int(11) NOT NULL,
  `slide_rev_id` int(11) NOT NULL,
  `deck_rev_id` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `message`
--

CREATE TABLE IF NOT EXISTS `message` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `sender_id` tinyint(4) NOT NULL,
  `receiver_id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `content` text NOT NULL,
  `msg_type` enum('pm','editorship','comment') DEFAULT 'pm',
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `notifications`
--

CREATE TABLE IF NOT EXISTS `notifications` (
  `user_id` int(11) NOT NULL,
  `message` text COLLATE utf8_unicode_ci NOT NULL,
  `timestamp` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `preference`
--

CREATE TABLE IF NOT EXISTS `preference` (
  `user_id` int(10) unsigned NOT NULL,
  `preference` varchar(255) CHARACTER SET latin1 NOT NULL,
  `value` varchar(255) CHARACTER SET latin1 NOT NULL,
  UNIQUE KEY `user_id` (`user_id`,`preference`,`value`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `preference`
--

INSERT INTO `preference` (`user_id`, `preference`, `value`) VALUES
(1, 'deck-9-theme', '2');

-- --------------------------------------------------------

--
-- Table structure for table `questions`
--

CREATE TABLE IF NOT EXISTS `questions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `item_id` int(11) NOT NULL,
  `question` text COLLATE utf8_unicode_ci NOT NULL,
  `difficulty` float NOT NULL DEFAULT '0',
  `guessing` float NOT NULL,
  `user_id` int(11) NOT NULL,
  `based_on` int(11) DEFAULT NULL,
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `mark` enum('suggested','doubtful','accepted') COLLATE utf8_unicode_ci NOT NULL DEFAULT 'accepted',
  `diff_count` float DEFAULT NULL,
  `incorrect` float DEFAULT '0',
  `all_answers` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `service_table`
--

CREATE TABLE IF NOT EXISTS `service_table` (
  `deck_revision_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `short_urls`
--

CREATE TABLE IF NOT EXISTS `short_urls` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `short` varchar(6) NOT NULL,
  `url` varchar(1000) NOT NULL,
  `stamped` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `user_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `short` (`short`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `slide`
--

CREATE TABLE IF NOT EXISTS `slide` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `description` tinytext CHARACTER SET utf8,
  `language` tinytext COLLATE utf8_unicode_ci,
  `translated_from` int(11) DEFAULT NULL,
  `translated_from_revision` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=64 ;

--
-- Dumping data for table `slide`
--

INSERT INTO `slide` (`id`, `user_id`, `description`, `language`, `translated_from`, `translated_from_revision`) VALUES
(1, 1, NULL, '-', NULL, NULL),
(2, 1, NULL, 'en-English', NULL, NULL),
(3, 1, NULL, 'en-English', NULL, NULL),
(4, 1, NULL, 'en-English', NULL, NULL),
(5, 1, NULL, 'en-English', NULL, NULL),
(6, 1, NULL, 'en-English', NULL, NULL),
(7, 1, NULL, '-', NULL, NULL),
(8, 1, NULL, 'en-English', NULL, NULL),
(9, 1, NULL, 'en-English', NULL, NULL),
(10, 1, NULL, '-', NULL, NULL),
(11, 1, NULL, 'en-English', NULL, NULL),
(12, 1, NULL, 'en-English', NULL, NULL),
(13, 1, NULL, 'en-English', NULL, NULL),
(14, 1, NULL, 'en-English', NULL, NULL),
(15, 1, NULL, 'en-English', NULL, NULL),
(16, 1, NULL, 'en-English', NULL, NULL),
(17, 1, NULL, '-', NULL, NULL),
(18, 1, NULL, 'en-English', NULL, NULL),
(19, 1, NULL, 'en-English', NULL, NULL),
(20, 1, NULL, 'en-English', NULL, NULL),
(21, 1, NULL, 'en-English', NULL, NULL),
(22, 1, NULL, 'en-English', NULL, NULL),
(23, 1, NULL, '-', NULL, NULL),
(24, 1, NULL, 'en-English', NULL, NULL),
(25, 1, NULL, 'en-English', NULL, NULL),
(26, 1, NULL, 'en-English', NULL, NULL),
(27, 1, NULL, '-', NULL, NULL),
(28, 1, NULL, 'en-English', NULL, NULL),
(29, 1, NULL, 'en-English', NULL, NULL),
(30, 1, NULL, 'en-English', NULL, NULL),
(31, 1, NULL, 'en-English', NULL, NULL),
(32, 1, NULL, 'en-English', NULL, NULL),
(33, 1, NULL, 'en-English', NULL, NULL),
(34, 1, NULL, 'en-English', NULL, NULL),
(35, 1, NULL, 'en-English', NULL, NULL),
(36, 1, NULL, 'en-English', NULL, NULL),
(37, 1, NULL, 'en-English', NULL, NULL),
(38, 1, NULL, '-', NULL, NULL),
(39, 1, NULL, 'en-English', NULL, NULL),
(40, 1, NULL, 'en-English', NULL, NULL),
(41, 1, NULL, 'en-English', NULL, NULL),
(42, 1, NULL, '-', NULL, NULL),
(43, 1, NULL, 'en-English', NULL, NULL),
(44, 1, NULL, 'en-English', NULL, NULL),
(45, 1, NULL, 'en-English', NULL, NULL),
(46, 1, NULL, 'en-English', NULL, NULL),
(47, 1, NULL, 'en-English', NULL, NULL),
(48, 1, NULL, 'en-English', NULL, NULL),
(49, 1, NULL, 'en-English', NULL, NULL),
(50, 1, NULL, 'en-English', NULL, NULL),
(51, 1, NULL, 'en-English', NULL, NULL),
(52, 1, NULL, 'en-English', NULL, NULL),
(53, 1, NULL, '-', NULL, NULL),
(54, 1, NULL, 'en-English', NULL, NULL),
(55, 1, NULL, 'en-English', NULL, NULL),
(56, 1, NULL, 'en-English', NULL, NULL),
(57, 1, NULL, 'en-English', NULL, NULL),
(58, 1, NULL, 'en-English', NULL, NULL),
(59, 1, NULL, 'en-English', NULL, NULL),
(60, 1, NULL, 'en-English', NULL, NULL),
(61, 1, NULL, 'en-English', NULL, NULL),
(62, 1, NULL, 'en-English', NULL, NULL),
(63, 1, NULL, 'en-English', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `slide_revision`
--

CREATE TABLE IF NOT EXISTS `slide_revision` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `slide` int(10) unsigned NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `content` text COLLATE utf8_unicode_ci NOT NULL,
  `user_id` int(10) unsigned NOT NULL,
  `based_on` int(10) unsigned DEFAULT NULL,
  `popularity` int(11) NOT NULL DEFAULT '0',
  `comment` text COLLATE utf8_unicode_ci,
  `note` text COLLATE utf8_unicode_ci,
  `license` enum('CC0','CC BY','CC BY-SA') COLLATE utf8_unicode_ci NOT NULL DEFAULT 'CC BY',
  `translation_status` enum('original','google','revised') COLLATE utf8_unicode_ci NOT NULL DEFAULT 'original',
  `translator_id` int(11) DEFAULT NULL,
  `translated_from_revision` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  FULLTEXT KEY `content` (`content`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=73 ;

--
-- Dumping data for table `slide_revision`
--

INSERT INTO `slide_revision` (`id`, `slide`, `timestamp`, `content`, `user_id`, `based_on`, `popularity`, `comment`, `note`, `license`, `translation_status`, `translator_id`, `translated_from_revision`) VALUES
(1, 1, '2013-08-29 17:44:33', '<h2>new slide</h2>', 1, NULL, 0, NULL, NULL, 'CC BY', 'original', NULL, NULL),
(2, 2, '2013-08-29 17:44:33', '<h2>Benefits for Educators, Lecturers and Teachers</h2><ul style=""><li>significantly increase the <b>user base</b> by making the content accessible to a world-wide audience<br></li><li>get your high-quality e-learning content <b>translated </b>into many different languages<br></li><li><b>engage students</b> in contributing to and discussing the slides<br></li><li style="">easily create <b>(self-)assessment tests</b> for students<br></li><li> involve <b>peer-educators</b> in improving and maintaining the quality and attractiveness of your e-learning content<br></li><li>increase the <b>reputation</b> in the community, by sharing qualitative e-learning content</li></ul>', 1, NULL, 0, 'imported', NULL, 'CC BY', 'original', NULL, NULL),
(3, 3, '2013-08-29 17:44:33', '<h2>Benefits for Students</h2><ul><li style="text-align: left;"><b>view</b> rich-learning content right in a browser</li><li style="text-align: left;"><b>discuss</b> particular content (e.g. a slide or question) with other students and instructors</li><li style="text-align: left;"><b>contribute </b>additional content, improvements and feedback</li><li style="text-align: left;">assess learning progress using the <b>questionnaires</b> attached to presentations</li></ul>', 1, NULL, 0, 'imported', NULL, 'CC BY', 'original', NULL, NULL),
(4, 4, '2013-08-29 17:44:33', '<h2>Benefits for Schools and Universities</h2><ul><li>make the e-learning content <b>easily accessible</b> (each presentation and slide has its own URL)</li><li>leverage the wisdom of <b>educator crowd</b>, which can collaborate efficiently in creating rich educational content</li><li>make the e-learning content produced in the organization really <b>re-usable and re-mixable</b></li><li>increase the <b>reputation</b> of the school by sharing the quality e-learning content</li></ul>', 1, NULL, 0, 'imported', NULL, 'CC BY', 'original', NULL, NULL),
(5, 5, '2013-08-29 17:44:33', '<h2>SlideWiki for Companies</h2><p>Presentations are a crucial element of the corporate knowledge exchange. SlideWiki can help to:</p><ul><li>make the knowledge available in your company easily&nbsp;accessible&nbsp;to everyone (in your company)</li><li>engage employees in sharing and reusing knowledge available in presentations</li><li>in addition to the public SlideWiki portal companies can install and run a SlideWiki instance inside their corporate Intranet with access&nbsp;control</li></ul><p><br></p><p><br></p>', 1, NULL, 0, 'imported', NULL, 'CC BY', 'original', NULL, NULL),
(6, 6, '2013-08-29 17:44:33', '<h2>SlideWiki for Humanity</h2><ul><li><b>Education is one of the main factors for societal progress</b> (in the <a style="" target="_blank" href="http://en.wikipedia.org/wiki/Human_Development_Index" class="aloha aloha-link-text">Human Development Index</a>, for example, education) is weighted one third)</li><li>However, despite huge investments into e-learning the <b>potential of the Internet and crowd-sourcing techniques for e-learning is still not sufficiently explored</b></li><li>With SlideWiki we aim to dramatically improve the efficiency and effectiveness of the <b>collaborative creation of rich learning material</b> for online and offline use</li><li>With its semi-automatic translation and liberal licensing SlideWiki aims to <b>make educational content dramatically more accessible to learners in developed and developing countries</b><br></li></ul>', 1, NULL, 0, 'imported', NULL, 'CC BY', 'original', NULL, NULL),
(7, 7, '2013-08-29 17:44:57', '<h2>new slide</h2>', 1, NULL, 0, NULL, NULL, 'CC BY', 'original', NULL, NULL),
(8, 8, '2013-08-29 17:44:57', '<h2>How to create great educational content</h2><ul><li>structure your lecture reasonably, a deck should have between 3-10 slides - do not overstructure </li><li>a good lecture covers introduction, prerequisites, learning goals, references (books, standards, websites, conferences, workshops) as well as tasks and mini projects </li><li>choose&nbsp;neutral&nbsp;examples in your slides (e.g. books or history) these should be very well known topics, so also people in other cultures can relate to them </li><li>add at least one question to every slide, so learners can check whether they grasped the idea</li><li>avoid  lengthy full sentences, package content in easily digestible doses, use bullet points </li><li>use speaking titles for your slides </li><li>illustrate your material with good examples and visualizations</li><li>beef up your decks with some nice images – Google Image search allows to <a href="https://www.google.de/search?as_st=y&amp;tbm=isch&amp;hl=en&amp;as_q=data&amp;as_epq=&amp;as_oq=&amp;as_eq=&amp;cr=&amp;as_sitesearch=&amp;safe=images&amp;tbs=sur:fmc&amp;tbo=d&amp;biw=2133&amp;bih=1130&amp;sei=rxQQUabYHM3JswbF14DQBA#hl=en&amp;tbo=d&amp;as_st=y&amp;tbs=sur:fmc%2Cimgo%3A1&amp;tbm=isch&amp;sa=1&amp;q=semantic+web&amp;oq=semantic+web&amp;gs_l=img.3..0l7.13880.16082.0.16520.12.10.0.2.2.0.67.398.10.10.0...0.0...1c.1.2.img.Vp9OO9EH4jk&amp;fp=1&amp;biw=2133&amp;bih=1130&amp;bav=on.2,or.r_gc.r_pw.r_cp.r_qf.&amp;cad=b&amp;sei=4xoSUZ_zBIHoswbshIGIBA" class="aloha-link-text" style="">search for CC-BY-SA licensed images</a></li></ul>', 1, NULL, 0, 'imported', NULL, 'CC BY', 'original', NULL, NULL),
(9, 9, '2013-08-29 17:44:57', '<h2>Don''t reinvent the wheel</h2><p>Look for existing lecture material you can reuse</p><p>Look for existing material in SlideWiki in other languages, which you can translate</p><p>Ask the original authors for permission to reuse and re-license (under CC-BY-SA) their content and acknowledge them as original authors</p><p>Good, recent text books are also usually a good basis for a lecture - inquire with the authors whether they would support a lecture on SlideWiki e.g. by providing you with the content in a machine-readable format</p>', 1, NULL, 0, 'imported', NULL, 'CC BY', 'original', NULL, NULL),
(10, 10, '2013-08-29 17:45:16', '<h2>new slide</h2>', 1, NULL, 0, NULL, NULL, 'CC BY', 'original', NULL, NULL),
(11, 11, '2013-08-29 17:45:16', '<h2>Revisioning</h2><ul><li>SlideWiki supports <b>versioning</b>, <b>forking/branching</b> and <b>merging</b>&nbsp;for slides and decks (similar as GitHub and Bitbucket do for software code or ordinary Wikis for text).</li><li>SlideWiki ensures that every author''s personal revisions of slides and decks are always <b>preserved</b></li><li>New version of slides/decks are created based on the following criteria:</li></ul><p></p><p align="center">  </p><img src="http://slidewiki.aksw.org/documentation_files/revisions.png">', 1, NULL, 0, 'imported', NULL, 'CC BY', 'original', NULL, NULL),
(12, 12, '2013-08-29 17:45:16', '<h2>Persistent URL Scheme</h2><p>SlideWiki provides a URL Scheme aiming to make content persistently accessible</p><p>For example, you can always access:</p><ul><li>A particular revision of a slide/deck:<br>http://slidewiki.org/slide/17706<br>http://slidewiki.org/deck/56<br class="aloha-end-br"></li><li>The latest revision of a slide:<br>http://slidewiki.org/slide/17706/latest<br>http://slidewiki.org/deck/56/latest<br class="aloha-end-br"></li><li>The latest revision of a slide of a particular user:<br>http://slidewiki.org/slide/17706/user/1<br>http://slidewiki.org/deck/56/user/1<br class="aloha-end-br"></li></ul>', 1, NULL, 0, 'imported', NULL, 'CC BY', 'original', NULL, NULL),
(13, 13, '2013-08-29 17:45:16', '<h2>Visibility, Licensing and Attribution</h2><p>Users can set the visibility status of the deck. Invisible decks will not be listed in the SlideWiki home page.</p><p>SlideWiki is committed to open knowledge and giving credit to original authors and contributors. All contributions on SlideWiki (including images, styles etc.) have to be licensed under the<a href="http://creativecommons.org/licenses/by/3.0/" class="aloha aloha-link-text" target="_blank" style=""> Creative Commons Attribution Share Alike license (CC-BY-SA)</a>.</p><p>SlideWiki tracks all contributors to a particular slide (respectively deck) and lists these contributors to acknowledge their contributions.</p><p><br class="aloha-end-br"></p>          <div><img src="./upload/media/images/1\\1.png"></div>', 1, NULL, 0, 'imported', NULL, 'CC BY', 'original', NULL, NULL),
(14, 14, '2013-08-29 17:45:16', '<h2>Editor Groups</h2><ul><li>users can create editor groups for each deck: <b>enables multiple users to easily work on a presentation</b> without creating new revisions for every change</li><li>To manage editors of a deck, go to the <i>Edit tab</i> of the respective deck. Then add users to your deck by entering their username or email address.<ul><li>You can assign new editors to all sub-decks owned by you.</li><li>Current editors other than the owner of the deck can also add editors to the deck.</li></ul></li></ul>          <div><img src="http://slidewiki.aksw.org/documentation_files/editorgroups.png"></div>', 1, NULL, 0, 'imported', NULL, 'CC BY', 'original', NULL, NULL),
(15, 15, '2013-08-29 17:45:16', '<h2>Translation</h2><ul><li> Slidewiki allows to automatically translate presentations using&nbsp;<a style="" target="_blank" href="http://translate.google.com" class="aloha aloha-link-text">Google Translate</a></li><li>Presentations can be automatically translated into 54 languages and then <b>edited</b> and <b>saved</b> independently from the original.</li><li>After the original deck was changed, the translation deck start to have notification about that. There is the possibility to <b>compare</b> the revisions and to <b>update</b> the translation in accordance with changes. <br class="aloha-end-br"></li></ul>', 1, NULL, 0, 'imported', NULL, 'CC BY', 'original', NULL, NULL),
(16, 16, '2013-08-29 17:45:16', '<h2>How to translate your deck</h2><ol><li>Make sure that you are logged in SlideWiki<br class="aloha-end-br"></li><li>Select a deck or subdeck in the tree</li><li>Open the list of existing translations in the top-right corner (see screenshot below)<br></li><li>You can open existing translations of the deck by clicking on one of the languages</li><li>If the desired language is not available in the list or if the translation is <span id="result_box" class="short_text" lang="en"><span class="hps">outdated</span></span>, use the translate button at the bottom of the list</li><li>SlideWiki will redirect you to the translated deck. However, the translation will not be ready momentarily, as it takes time to manage the translation process. Please, wait a few minutes and reload the page with the translated deck or return to it later.<br></li><li>After the translation is completed, you can revise it <br></li></ol><div><img src="./upload/media/images/1\\2.png"></div>', 1, NULL, 0, 'imported', NULL, 'CC BY', 'original', NULL, NULL),
(17, 17, '2013-08-29 17:45:43', '<h2>new slide</h2>', 1, NULL, 0, NULL, NULL, 'CC BY', 'original', NULL, NULL),
(18, 18, '2013-08-29 17:45:43', '<h2>Help creating great educational resources</h2><p>Many people in the world lack access to educational material</p><p>Help us to create great educational material covering as many domains and as many languages as <span style="font-size: 16px; line-height: 1.25;">possible:</span></p><ul><li>Look for decks at SlideWiki, whose domain you know</li><li>Review the content of decks and help&nbsp;improving&nbsp;them</li><li>Add self-assessment questions to the slides</li><li>Translate decks covering topics you know well into your mother tongue</li><li>Look for existing presentations and e-learning material, which could be imported into SlideWiki</li></ul>', 1, NULL, 0, 'imported', NULL, 'CC BY', 'original', NULL, NULL),
(19, 19, '2013-08-29 17:45:43', '<h2>Lecture Wishlist</h2><p>The following online courses are waiting to be imported and translated in SlideWIki:</p><ul><li><a href="http://www.software-engin.com/teaching/systems-engineering-for-lscits" class="" style="">Systems Engineering for (LSCITS)</a></li><li><a href="http://nlp.stanford.edu/IR-book/" class="" style="">Introduction to Information Retrieval</a></li><li><a href="http://aima.cs.berkeley.edu/instructors.html#homework" class="" style="">Artificial Intelligence a Modern Approach</a></li><li><a href="http://pages.cs.wisc.edu/~dbbook/openAccess/thirdEdition/slides/slides3ed.html" class="aloha-link-text" style="">Database Management Systems</a></li><li>...</li></ul>', 1, NULL, 0, 'imported', NULL, 'CC BY', 'original', NULL, NULL),
(20, 20, '2013-08-29 17:45:43', '<h2>Spread the Word</h2><p>We are convinced that SlideWiki can have a positive impact on many different aspects.</p><p>Help us spreading the word about SlideWiki:</p><ul><li>organize new SlideWiki lectures in your domain of expertise by devising a curriculum and mobilizing other people to contribute content to this curriculum</li><li>tell your friends, colleagues, peers about SlideWiki in your language by email, on Twitter in Social networks, ...</li><li>keep in touch with SlideWiki by subscribing to our <a href="http://blog.aksw.org/category/projects/slidewiki/" class="" style="">news </a>and/or <a href="https://groups.google.com/d/forum/slidewiki" class="" style="">mailinglist</a></li><li>become a SlideWiki&nbsp;ambassador or domain curator&nbsp;</li></ul>', 1, NULL, 0, 'imported', NULL, 'CC BY', 'original', NULL, NULL),
(21, 21, '2013-08-29 17:45:43', '<h2>Become a SlideWiki Ambassador</h2><p>We aim to establish a network of local, regional and national SlideWiki ambassadors, which:</p><ul><li>represent the SlideWiki community in their region, present SlideWiki at relevant conventions and events</li><li>support the curation of localized courseware</li><li>help building a local, regional or national SlideWiki OpenCourseWare community</li></ul><p>If you are interested to become a SlideWiki Ambassador please contact us.</p>', 1, NULL, 0, 'imported', NULL, 'CC BY', 'original', NULL, NULL),
(22, 22, '2013-08-29 17:45:43', '<h2>Become a SlideWiki Domain Curator</h2><p>If you are an expert in a certain domain (e.g. history, mathematics, engineering etc.) you can support SlideWiki by help curating content in your domain of expertise:</p><ul><li>help us&nbsp;acquiring additional OpenCourseWare in your domain</li><li>assess the quality of existing OpenCourseWare in your domain</li><li>represent SlideWiki in your community</li></ul>', 1, NULL, 0, 'imported', NULL, 'CC BY', 'original', NULL, NULL),
(23, 23, '2013-08-29 17:46:04', '<h2>new slide</h2>', 1, NULL, 0, NULL, NULL, 'CC BY', 'original', NULL, NULL),
(24, 24, '2013-08-29 17:46:04', '<h2>Birds Eye''s View</h2><div><img src="http://slidewiki.aksw.org/documentation_files/architecture.jpg"></div>', 1, NULL, 0, 'imported', NULL, 'CC BY', 'original', NULL, NULL),
(25, 25, '2013-08-29 17:46:04', '<h2>Linked Data Interface</h2><ul><li>we configured the RDB2RDF <b>Triplify</b> tool to work with SlideWiki<br class="aloha-end-br"></li><li>we <b>mapped</b> SlideWiki content to RDF by Triplify<br></li><li>we <b>published</b> the results on Web of Data</li><li>the SlideWiki Linked Data interface is available via <a style="" target="_blank" href="http://slidewiki.org/triplify" class="aloha-link-text">slidewiki.org/triplify</a>&nbsp; </li><li>SlideWiki is currently mapped to FOAF, SIOC, CC, Dublin Core vocabularies</li><li>Support for W3C PROV and SPARQL endpoint via <a href="http://aksw.org/Projects/SparqlMap.html" class="aloha-link-text" style="background-color: rgb(128, 181, 242);">SparqlMap</a> is planned</li></ul><p><br class="aloha-end-br"></p>', 1, NULL, 0, 'imported', NULL, 'CC BY', 'original', NULL, NULL),
(26, 26, '2013-08-29 17:46:04', '<h2>Used tools and APIs</h2><ul>   <li>     <a style="" href="http://php.net" class="aloha-link-text">       PHP      </a>     as server-side scripting language   </li>   <li>     <a style="" href="http://www.mysql.com/" class="aloha-link-text">       MySQL     </a>     as database backend   </li>   <li>     <a style="" href="http://nodejs.org/" class="aloha-link-text">       Node.js     </a>     to control presentations remotely   </li>   <li>     <a style="" href="http://jquery.com/" class="aloha-link-text">       JQuery      </a>     and various JQuery plugins   </li>   <li>     <a style="" href="http://codemirror.net/" class="aloha-link-text">       CodeMirror      </a>     for source code highlighting&nbsp;   </li>   <li>     <a style="" href="http://imakewebthings.com/deck.js/" class="aloha-link-text">       deck.js     </a>     for modern HTML presentation   </li>   <li>     <a style="" href="http://code.google.com/p/svg-edit/" class="aloha-link-text">       SVG-edit     </a>     for drawing SVG images   </li>   <li>     <a style="" href="http://aloha-editor.org/" class="aloha-link-text">       ALOHA-editor     </a>     for WYSIWYG slide authoring   </li>   <li>     <a style="" href="http://twitter.github.com/bootstrap/" class="aloha-link-text">       Twitter Bootstrap     </a>     as base CSS framework     <br>   </li> </ul>', 1, NULL, 0, 'imported', NULL, 'CC BY', 'original', NULL, NULL),
(27, 27, '2013-08-29 17:46:23', '<h2>new slide</h2>', 1, NULL, 0, NULL, NULL, 'CC BY', 'original', NULL, NULL),
(28, 28, '2013-08-29 17:46:23', '<h2>Playing slides</h2><p></p>           <h4>Please use the browser fullscreen mode (by pressing <b>F11</b>) for playing your slides.</h4><p></p><h4>You can use <b>arrows </b>(up,down, right, left) as well as ''<b>space</b>'', ''<b>enter</b>'' buttons for navigation.</h4><p></p><h4>The following shortcuts can also be used when playing slides:</h4><ul><li><h4>''<b>S</b>'' : enable/disable scaling.</h4></li><li><h4>''<b>F</b>'' : enable/disable full slide size.</h4></li><li><h4>''<b>M</b>'' : go to menu for the list of slides.</h4></li><li><h4>''<b>G</b>'': go to a specific slide by entering its number.</h4><p>* Please use your browser zooming feature (<span class="st">[<em>CTRL</em> +] and </span><span class="st">[<em>CTRL</em> -]</span>) to adjust your presentation if needed.</p><p>* SlideWiki also supports zoomable presentations.Try a demo <a href="http://slidewiki.org/playImpress/style/9/deck/56" class="aloha-link-text" target="_blank" style="">here</a>.</p></li></ul>', 1, NULL, 0, 'imported', NULL, 'CC BY', 'original', NULL, NULL),
(29, 29, '2013-08-29 17:46:23', '<h2>Import & Export</h2><p>SlideWiki allows to import&nbsp;&amp; export presentations from:</p><ul><li><b>Powerpoint </b>(.pptx format, import only)<ul><li>Currently, only raster images are imported from Powerpoint, but import of vector graphic (converted to <b>SVG) is planned</b>.</li></ul></li><li><b>deck.js HTML</b><ul><li>allows users to work&nbsp;<b>locally</b> and increases content security (backup your presentations)</li></ul></li><li><b>LaTeX </b>(experimental import only)</li><li><b>SCORM package</b> (export only)<br><ul><li>allows to move content between different Learning Management Systems<br></li></ul></li></ul>', 1, NULL, 0, 'imported', NULL, 'CC BY', 'original', NULL, NULL),
(30, 30, '2013-08-29 17:46:23', '<h2>Attribution</h2><p>Despite its focus on collaboration, SlideWiki strives to be a good steward of preserving and acknowledging the original creator of a certain contribution:&nbsp;</p><ul><li>All content contributed to SlideWiki must be licensed under the <a href="http://creativecommons.org/licenses/by-sa/3.0/" class="aloha-link-text" style="">Creative Commons Attribution-Share-Alike License</a><ul><li>You can additionally license your content under even more liberal licensing schemes (e.g. CC-BY or CC0), by simply adding a respective note to the deck description.</li></ul></li><li>All changes and revisions performed by a certain user are&nbsp;preserved&nbsp;and the respective user is added to the list of contributors for a certain item (i.e. slide, deck, question)</li><li>If content is copied from other sources SlideWiki allows to attribute these sources on a slide ("Add original source"&nbsp;<span style="font-size: 16px;">&nbsp;below the speaker notes</span>) and deck basis ("Original source" on the deck edit tab)</li></ul>', 1, NULL, 0, 'imported', NULL, 'CC BY', 'original', NULL, NULL),
(31, 31, '2013-08-29 17:46:23', '<h2>Social networking</h2><p>           SlideWiki allows to follow the update stream of slides, decks and users&nbsp;</p><p>Currently, you can login to SlideWiki using your Facebook account</p><p>Further integration with social networks is planned</p>', 1, NULL, 0, 'imported', NULL, 'CC BY', 'original', NULL, NULL),
(32, 32, '2013-08-29 17:46:23', '<h2>Code highlighting</h2><h5>SlideWiki employs    <a style="" href="http://codemirror.net/" class="aloha-link-text">     CodeMirror&nbsp;   </a> to highlight sourcecode within slides. </h5> <ul>   <li>     To use this feature <ul><li>go to editor Insert tab and then choose "Insert Code Snippet" or<br></li><li>go to source code and add a &lt;     <b>       DIV     </b>     &gt; tag containing the following attributes:      <b>       class     </b>     ="code"      <b>       mode     </b>     ="your desirable mode"     <br>   </li></ul></li>   <li>     The following modes are currently supported :      <b>       javascript     </b>     ,      <b>       css     </b>     ,      <b>       xml     </b>     ,      <b>       htmlmixed     </b>     ,      <b>       php     </b>     ,      <b>       ntriples     </b>     ,      <b> sparql</b></li><li>If you want to put more than one code snippet within a slide, use <b>&lt;TEXTAREA&gt;</b> tag instead of <b>&lt;DIV&gt;</b><br></li>   <li>     For example:   </li> </ul>  <div style="" class="code passive-code" mode="htmlmixed">   &lt;p vocab="http://schema.org/" typeof="Person"&gt;   My name is   &lt;span property="name"&gt;Sören Auer&lt;/span&gt;   and you can give me a ring via   &lt;span property="telephone"&gt;49-341-97-32367&lt;/span&gt;   or visit    &lt;a property="url" href="http://aksw.org/SoerenAuer.html"&gt;my homepage&lt;/a&gt;.   &lt;/p&gt; </div>  <br style="">', 1, NULL, 0, 'imported', NULL, 'CC BY', 'original', NULL, NULL),
(33, 33, '2013-08-29 17:46:23', '<h2>Globally Recognized Avatars</h2><h5>SlideWiki supports <a style="" href="https://en.gravatar.com/" class="aloha-link-pointer">Gravatar</a> for using <i>Globally Recognized Avatars</i>.</h5><p>Your Gravatar is an image (based on the email you have registered with in SlideWiki) that appears next to your name when you contributed slides/decks, comments, etc. Avatars help identify your contributions on SlideWiki.</p><p>* <i>In order to set your avatar, you need to register your corresponding email address (which is used by SlideWiki) at the&nbsp;<a style="" href="https://en.gravatar.com/" class="aloha-link-pointer">Gravatar</a> website</i>.<br></p>', 1, NULL, 0, 'imported', NULL, 'CC BY', 'original', NULL, NULL),
(34, 34, '2013-08-29 17:46:23', '<h2>Messaging</h2><p>&nbsp;Users can send messages to each other.</p><p>To send message to other users, go to the intended user profile and click on the "<i>Write messag</i>e" link<br class="aloha-end-br"></p>', 1, NULL, 0, 'imported', NULL, 'CC BY', 'original', NULL, NULL),
(35, 35, '2013-08-29 17:46:23', '<h2>Remote control for presentations</h2><p>       </p><p></p><ul><li>SlideWiki allows to sync the display of a presentation on several devices, for example, a&nbsp;presenter&nbsp;PC/notebook and tablets/smartphones of people in the audience</li><li>If the presenter switches slides, so will all the devices, which follow the presentation</li><li>Once you play a presentation, a QR code together with a short link will be displayed and can be shared with other users&nbsp;</li>   <li> Users who open the link will see the presentation as you are playing it so any change in slide is immediately reflected in other users browsers&nbsp;</li><li>This feature can also be used as a remote&nbsp;control&nbsp;for your presentation, when you play the presentation on your smartphone and open the respective link on the presenter PC</li> </ul>', 1, NULL, 0, 'imported', NULL, 'CC BY', 'original', NULL, NULL),
(36, 36, '2013-08-29 17:46:23', '<h2>SlideWiki on Mobile Devices</h2><p>SlideWiki can be used on smartphones, tablets and other mobile devices</p><p>Editing functionality on these devices might, however, be limited&nbsp;</p>', 1, NULL, 0, 'imported', NULL, 'CC BY', 'original', NULL, NULL),
(37, 37, '2013-08-29 17:46:23', '<h2>Search and Replace</h2><ul><li>&nbsp;Users can search within a deck content by clicking on the search icon on top of the presentation tree and entering their desirable search keywords. <br></li></ul>          <div><img src="./upload/media/images/1\\3.png"></div><div><br class="aloha-end-br"></div>          <ul><li>Users (when logged in) can select "<b>Find and Replace</b>" feature from the context menu by right clicking on nodes in the tree.<br></li></ul>', 1, NULL, 0, 'imported', NULL, 'CC BY', 'original', NULL, NULL),
(38, 38, '2013-08-29 17:46:43', '<h2>new slide</h2>', 1, NULL, 0, NULL, NULL, 'CC BY', 'original', NULL, NULL),
(39, 39, '2013-08-29 17:46:43', '<h2>Basic Information</h2><ul><li>SlideWiki allows to <b>attach multiple-choice questions to each individual slide</b><ul><li>if slides are copied or reused, so are the questions attached to them</li></ul></li><li>For each presentation the learner can start a <b>self-assessment&nbsp;test</b>, which launches a multiple-choice test composed of all or a selection of questions attached to slides of the presentation&nbsp;</li><li>Such questionnaires are <b>structured</b> according to the structure of the presentation, which allows to apply <b>module-based score</b> systems without additional teacher''s work.</li><li>SlideWiki allows to score the results with 5 <b>different algorithms</b>, including a novel one.<br class="aloha-end-br"></li></ul>', 1, NULL, 0, 'imported', NULL, 'CC BY', 'original', NULL, NULL),
(40, 40, '2013-08-29 17:46:43', '<h2>Easy Question</h2><p><span style="font-size: 16px; line-height: 1.25;">SlideWiki supports the assisted creation of questions</span>.</p><p>The respective tool "Easy Question" can be found in the editor menu.</p><p>The process includes these steps:</p><ol><li>Being logged in, click on the slide content to enable the editor menu</li><li>Select the fragment of the text, that includes the material for question and answer alternatives</li><li>In the editor menu switch to the "Easy Quest" tab and click the round yellow button with a question mark:</li></ol><p><br class="aloha-end-br"></p><div><img src="./upload/media/images/1\\4.png"></div>', 1, NULL, 0, 'imported', NULL, 'CC BY', 'original', NULL, NULL),
(41, 41, '2013-08-29 17:46:43', '<h2>Easy Question result</h2><p>After selecting a text fragment and clicking on the Easy Quest button, you are redirected to the question tab, and a new question is created from the selected text fragment.</p><p>Check and edit the question and alternatives, select the appropriate difficulty, add explanations, if necessary, and click the Save button to assign the question to the slide.</p><p>For example, the text fragment from the previous slide turned into following question:<br></p><div><img src="./upload/media/images/1\\5.png"></div>', 1, NULL, 0, 'imported', NULL, 'CC BY', 'original', NULL, NULL),
(42, 42, '2013-08-29 17:47:04', '<h2>new slide</h2>', 1, NULL, 0, NULL, NULL, 'CC BY', 'original', NULL, NULL),
(43, 43, '2013-08-29 17:47:04', '<h2>Structuring a presentation</h2><p>To structure your presentation you can use the context menu which is shown by <b>right clicking</b> on your deck.</p><p></p><p><img src="http://slidewiki.aksw.org/documentation_files/contextmenu.png"></p>You can use <b>drag and drop</b> in order to change the positions of slides within a deck. <img src="http://slidewiki.aksw.org/documentation_files/moving.png">', 1, NULL, 0, 'imported', NULL, 'CC BY', 'original', NULL, NULL),
(44, 44, '2013-08-29 17:47:04', '<h2>Editing Slides</h2><p>           <b>SlideWiki</b> employs <a class="aloha-link-text" href="http://aloha-editor.org/">Aloha-Editor</a> for editing slide content.It also uses <a href="http://code.google.com/p/svg-edit/">SVG-edit</a> for drawing shapes within an slide.<br class="aloha-end-br"></p><img src="http://slidewiki.aksw.org/documentation_files/wysiwyg.png"><p></p><p>Using these features you can add code, quotes, shapes and etc. to your slides. Some examples follow:</p><pre>&lt;div&gt; Hello World! &lt;/div&gt;<br class="aloha-end-br"></pre><blockquote><p>Food is an important part of a balanced diet!&nbsp;</p></blockquote><p align="center"><svg style="text-align: center;" width="181" height="99" xmlns="http://www.w3.org/2000/svg">  <g>   <title>Layer 1</title>   <path fill="#ff7f00" stroke="#000000" stroke-width="5" d="m47.4496,57.4618l-44.9496,-54.9618l79.1367,15.9235l-12.6619,13.3552l109.5252,57.53l-8.23,7.1913l-112.6909,-53.9344l-10.1295,14.8961l0,0.0001z" id="svg_2"></path>   <text fill="#000000" stroke="#000000" stroke-width="0" x="122.5" y="40.5" id="svg_3" font-size="24" font-family="serif" text-anchor="middle" xml:space="preserve">Use</text>  </g> </svg></p><p style="text-align: center;">*<i>Note</i>:<small style="text-align: center;"> It is recommended to edit the slides in<i><b> fullscreen mode</b></i></small>. </p>', 1, NULL, 0, 'imported', NULL, 'CC BY', 'original', NULL, NULL),
(45, 45, '2013-08-29 17:47:04', '<h2>Editing Slide HTML Code</h2><p>   Users familiar with HTML can easily edit slides'' source code. SlideWiki uses &nbsp; &nbsp;<a style="" target="_blank" href="http://codemirror.net/" class="aloha">     CodeMirror    </a>   to highlight the HTML source code. </p> <p>   <b>     WYSIWYG    </b>   and    <b>     source code   </b>   views are synchronized so that changes in one view will affect the other one instantly. </p> <p>   <img src="http://slidewiki.aksw.org/documentation_files/code_edit.png" style=""> </p>', 1, NULL, 0, 'imported', NULL, 'CC BY', 'original', NULL, NULL),
(46, 46, '2013-08-29 17:47:04', '<h2>LaTeX integration</h2><h5>   SlideWiki uses   <a class="aloha" href="http://www.mathjax.org/" target="_blank" style="">     MathJax    </a>   to display mathematical content. </h5> <h5>   You can use LaTeX&nbsp; expressions within your slides. For example: </h5> <pre>\\[\\left( \\sum_{k=1}^n a_k b_k \\right)^2 \\leq \\left( \\sum_{k=1}^n a_k^2 \\right) \\left( \\sum_{k=1}^n b_k^2 \\right)\\] </pre> <h5>   which will result in: </h5> <h5>   \\[\\left( \\sum_{k=1}^n a_k b_k \\right)^2 \\leq \\left( \\sum_{k=1}^n a_k^2 \\right) \\left( \\sum_{k=1}^n b_k^2 \\right)\\] </h5> <h5> You can also write inline LaTeX. For example: </h5>  <pre>  \\(a^{\\mathcal{I},\\mathcal{Z}} = a^{\\mathcal{I}} \\in \\Delta_{\\mathcal{I}}\\) </pre><h5> which will result in: \\(a^{\\mathcal{I},\\mathcal{Z}} = a^{\\mathcal{I}} \\in \\Delta_{\\mathcal{I}}\\)</h5><h5>   <br class="aloha-end-br"></h5><h5>For more TeX samples click    <a style="" target="_blank" href="http://www.mathjax.org/demos/tex-samples/" class="aloha">     here   </a>   . </h5> <p>   <br class="aloha-end-br"> </p>', 1, NULL, 0, 'imported', NULL, 'CC BY', 'original', NULL, NULL),
(47, 47, '2013-08-29 17:47:04', '<h2>Scalable Vector Graphics (SVG) Integration</h2><p> SlideWiki allows to integrate Scalable Vector Graphics (SVG)</p><ul><li>use the Pencil tool in the editor Insert tab</li></ul><p></p><svg id="svg0" width="356" height="293" xmlns="http://www.w3.org/2000/svg">  <!-- Created with SVG-edit - http://svg-edit.googlecode.com/ -->  <g>   <title>Layer 1</title>   <rect fill="#FF0000" stroke="#000000" stroke-width="5" x="2.5" y="114" width="239" height="101" id="svg_1"></rect>   <ellipse fill="#007fff" stroke="#000000" stroke-width="5" cx="57.5" cy="249" id="svg_2" rx="44" ry="41"></ellipse>   <g id="svg_34">    <g>     <title>Layer 1</title>     <g id="svg_33">      <path stroke="#000000" fill="none" stroke-width="3" d="m84.52582,127.25247l14.89053,-33.84233c-9.41129,-7.34883 -26.1713,-18.9518 -25.91345,-40.61108c-0.13864,-32.66167 44.37357,-53.17453 79.09439,-52.7939c46.15442,-0.06447 81.09271,24.04427 81.0282,52.60066c-0.06454,38.6769 -54.08331,63.817 -109.26227,50.47343l-39.8374,24.17322z"></path>     </g>    </g>   </g>   <text fill="#000000" stroke="#000000" stroke-width="0" x="154.5" y="75" id="svg_35" font-size="57" font-family="serif" text-anchor="middle" space="preserve">SVG</text>   <g id="svg_6">    <!-- Created with SVG-edit - http://svg-edit.googlecode.com/ -->    <g>     <path fill="#007fff" stroke="#000000" stroke-width="1.04685" d="m166.61292,141.88074c-0.0983,0 -0.19299,0.01392 -0.29114,0.01453l-48.85159,0l0,46.08899l0.14557,0c-0.05368,0.93573 -0.10413,1.86249 -0.14557,2.81079c-0.47128,10.78671 21.54465,18.61978 48.67142,18.61978c27.1268,0 50.55661,-7.40637 49.61401,-18.61978c-0.07953,-0.94629 -0.09189,-1.87506 -0.14557,-2.81079l0.14557,0l0,-46.08899l-48.85156,0c-0.09818,-0.00061 -0.19287,-0.01453 -0.29114,-0.01453z" id="svg_5"></path>     <path fill="#aad4ff" stroke="#000000" d="m215.8631,142.29773a49.25019,15.30356 0 1 1-98.5004,0a49.25019,15.30356 0 1 198.5004,0z" id="svg_4"></path>     <title>Layer 1</title>     <metadata id="svg_3">image/svg+xml</metadata>     <title>Layer 1</title>    </g>   </g>   <g id="svg_38">    <defs transform="translate(-142, -87) translate(0, 3) translate(382, 175) translate(-0) scale(0.400169) translate(0) translate(971.494, 495.611) scale(0.747635, 0.827176) translate(-971.494, -495.611)">     <foreignobject x="0" y="0" width="1" height="1" id="svg_37"></foreignobject>    </defs>    <metadata id="svg_36">Farm BuildingFarm BuildingbuildingfarmOpen Clip Art ProjectArtFavorPublic Domain2005/10/03image/svg+xmlhttp://purl.org/dc/dcmitype/StillImage</metadata>    <path fill-rule="evenodd" id="svg_32" d="m298.84872,175.79056l-5.35834,0.08939c-7.25034,0.13437 -14.46121,0.44586 -21.71243,1.06982c-2.65881,0.26678 -5.27695,0.57925 -7.93607,0.98013c-1.73166,0.26746 -3.42352,0.57925 -5.116,0.93573l-2.94034,0.75836c-1.28915,0.40085 -2.49756,0.84607 -3.74634,1.33664l-1.04742,0.53488l-0.96664,0.53491l-0.8461,0.62396l-0.76529,0.6683l-0.68515,0.8024l-0.52356,0.89172l-0.3222,1.02448l-0.12088,1.02548l0.04041,0.93576l0.12088,0.80237l0.20132,0.80237l0.28183,0.80237l0.36261,0.71268l0.44308,0.66864l1.00705,1.29227l1.24878,1.06979c0.72491,0.53491 1.45013,0.98013 2.21542,1.42603c0.84637,0.44553 1.69217,0.80203 2.57834,1.20322c0.96664,0.35648 1.93362,0.66864 2.94064,0.98077c2.2962,0.62363 4.59274,1.11386 6.96881,1.51505l2.61844,0.35617c3.66586,0.4465 7.3721,0.8027 11.07834,0.84738c1.65179,0 3.2225,-0.04468 4.83386,-0.26712c0.96667,-0.17844 1.85312,-0.35684 2.78,-0.6243c1.61139,-0.49023 3.14139,-1.11453 4.75308,-1.56036l1.20868,-0.31152c2.17535,-0.40115 4.31061,-0.49054 6.52576,-0.49054l2.77939,0.04471c4.43176,0 8.86288,-0.08939 13.29407,-0.22311c3.26288,-0.13373 6.52573,-0.3118 9.7886,-0.57892c3.62546,-0.26816 7.21085,-0.6243 10.7962,-1.11386c2.45749,-0.31247 4.83386,-0.71399 7.29138,-1.20389l3.10156,-0.71335c1.32956,-0.40082 2.65942,-0.80267 3.9881,-1.24789l2.17532,-0.93546l0.92688,-0.53522l0.84546,-0.57993l0.76593,-0.62363l0.64383,-0.71335l0.52417,-0.80237l0.36261,-0.9801l0.12082,-1.06949l-0.12082,-1.06982l-0.36261,-0.98047l-0.564,-0.80203l-0.68509,-0.71268l-0.76559,-0.57959l-0.84552,-0.53491l-1.97427,-0.93576l-2.41708,-0.80237c-1.40976,-0.40085 -2.81979,-0.71335 -4.26962,-1.02548c-2.2962,-0.40085 -4.63251,-0.75766 -6.96881,-1.06949c-12.81088,-1.47034 -25.70139,-1.64877 -38.55148,-1.64877l0,0z" clip-rule="evenodd"></path>    <path fill="#ffffff" fill-rule="evenodd" id="svg_31" d="m301.58771,177.70712c-29.24579,0 -53.09348,2.49615 -53.09348,9.44901c0,6.90753 10.71515,10.16138 26.46609,11.27621c15.75098,1.11383 10.39297,-3.78909 26.78836,-3.0751c29.24576,0 52.89212,-3.43289 52.89212,-9.40466c0,-5.97241 -23.84741,-8.24545 -53.0531,-8.24545l0,0z" clip-rule="evenodd"></path>    <path fill="none" id="svg_30" d="m318.82919,177.39496l20.94742,-3.11975h-43.38538l-31.78372,3.11975h54.22168l0,0z" clip-rule="evenodd"></path>    <path fill-rule="evenodd" id="svg_29" d="m344.28827,155.55589l-1.49026,32.62471l-23.84793,3.56601l1.85281,-37.39326l23.48538,1.20255l0,0z" clip-rule="evenodd"></path>    <path fill="#ffffff" fill-rule="evenodd" id="svg_28" d="m322.17252,156.00211l20.58514,1.06949l-1.32925,29.10376l-20.94775,3.11945l1.69186,-33.29269z" clip-rule="evenodd"></path>    <path fill="none" id="svg_27" d="m264.60751,177.39496l31.78372,-3.11975l-1.32925,-16.89214l-32.10596,-1.11385l1.65149,21.12573l0,0z" clip-rule="evenodd"></path>    <path fill-rule="evenodd" id="svg_26" d="m292.76547,158.98749l6.88861,-14.21722l-13.29376,-3.20882l23.92847,3.92213l7.08966,-12.83624l-31.17938,-10.2504l-20.3024,14.08383l-14.22037,21.97279l41.08917,0.53392z" clip-rule="evenodd"></path>    <path fill="#999999" fill-rule="evenodd" id="svg_25" d="m255.42267,156.26923l37.02087,0.49023l5.03552,-10.87502l-30.25284,-7.39809l-11.80356,17.78287l0,0z" clip-rule="evenodd"></path>    <path fill="#999999" fill-rule="evenodd" id="svg_24" d="m269.19962,136.48077l40.36426,7.26434l5.59976,-10.16135l-28.23904,-9.27061l-17.72498,12.16762z" clip-rule="evenodd"></path>    <path fill-rule="evenodd" id="svg_23" d="m309.24133,136.52513l12.76993,19.29855l-1.81271,35.96727h-56.96069l-1.77234,-35.96727l12.04471,-18.40747l18.20782,-11.85547l17.52328,10.96439l0,0z" clip-rule="evenodd"></path>    <path fill="#ffffff" fill-rule="evenodd" id="svg_22" d="m291.43091,128.23531l16.11356,10.29541l12.12518,17.33733l-1.53088,33.51611l-53.29514,-0.17841l-1.69156,-32.535l11.19864,-17.42703l17.0802,-11.00841z" clip-rule="evenodd"></path>    <path fill-rule="evenodd" id="svg_21" d="m336.71481,144.28003l14.30081,17.47139l-27.43277,-1.42665l-14.90485,-22.90855l28.0368,6.86382z" clip-rule="evenodd"></path>    <path fill="#999999" fill-rule="evenodd" id="svg_20" d="m310.20862,138.04082l25.37827,7.66586l11.68271,14.2616l-22.96179,-1.20323l-14.09918,-20.72423z" clip-rule="evenodd"></path>    <path fill-rule="evenodd" id="svg_19" d="m338.12454,146.77618l-1.28857,-2.45081l-16.83878,-11.40993l-33.5564,-9.71614l23.28403,16.71336l28.39972,6.86351z" clip-rule="evenodd"></path>    <path fill="#b3b3b3" fill-rule="evenodd" id="svg_18" d="m310.57062,137.95145l23.3244,6.01711l-15.38803,-9.80551l-24.85535,-7.53215l16.91898,11.32056z" clip-rule="evenodd"></path>    <path fill-rule="evenodd" id="svg_17" d="m286.92426,140.2245c1.28918,0 2.57864,0 3.86752,0c1.28888,0 2.57834,0 3.86722,0c0,2.13931 -0.0401,4.23363 -0.0401,6.28423c-0.04037,1.96124 -0.08047,3.96616 -0.08047,5.88304c-1.20871,0 -2.45776,0 -3.66583,0c-1.2084,0 -2.45752,0 -3.66559,0c-0.04037,-1.91689 -0.08078,-3.92213 -0.12088,-5.88304c-0.08105,-2.0506 -0.12146,-4.14459 -0.16187,-6.28423z" clip-rule="evenodd"></path>    <path fill-rule="evenodd" id="svg_16" d="m281.92914,173.65128h18.36911l-0.64444,17.33762h-16.87857l-0.8461,-17.33762z" clip-rule="evenodd"></path>    <path fill="none" id="svg_15" d="m309.16086,124.62531l3.54501,-0.53525h-7.37183l-5.31732,0.53525h9.14413l0,0z" clip-rule="evenodd"></path>    <path fill="none" id="svg_14" d="m300.01672,124.62531l5.31705,-0.53525l-0.20108,-2.85197l-5.3978,-0.17842l0.28183,3.56564z" clip-rule="evenodd"></path>    <path fill-rule="evenodd" id="svg_13" d="m303.52072,123.28802l5.76102,-6.37294l-7.04959,-2.49615l-8.41895,7.71056l9.70752,1.15854z" clip-rule="evenodd"></path>    <path fill="#999999" fill-rule="evenodd" id="svg_12" d="m297.11646,120.88158l6.36475,0.98045l3.46423,-4.01086l-4.55203,-1.64908l-5.27695,4.67949z" clip-rule="evenodd"></path>    <path fill-rule="evenodd" id="svg_11" d="m309.7652,133.36066l-6.24451,-4.45671l-4.30997,-1.20355l-0.362,-7.26469l5.72,-5.12535l5.39813,4.81354l4.75339,0.26712l-0.20166,13.68332l-4.75339,-0.71367z" clip-rule="evenodd"></path>    <path fill="#ffffff" fill-rule="evenodd" id="svg_10" d="m304.44757,117.36095l4.67291,4.45639l-0.20105,8.91411l-4.06946,-2.45146l-4.43115,-1.47069l-0.3219,-5.74931l4.35065,-3.69904z" clip-rule="evenodd"></path>    <path fill="#ffffff" fill-rule="evenodd" id="svg_9" d="m310.57062,121.32678l3.26315,0.17842l-0.24203,10.69693l-3.22247,-0.40118l0.20135,-10.47417l0,0z" clip-rule="evenodd"></path>    <path fill-rule="evenodd" id="svg_8" d="m312.06174,117.13785l6.92871,7.22034l-8.13803,-1.38197l-8.9021,-8.64665l10.11142,2.80829z" clip-rule="evenodd"></path>    <path fill="#cccccc" fill-rule="evenodd" id="svg_7" d="m306.22052,116.91475l5.23685,1.51537l4.18973,3.96651l-4.31088,-0.80205l-5.11569,-4.67982z" clip-rule="evenodd"></path>   </g>   <g id="svg_44">    <!-- Created with SVG-edit - http://svg-edit.googlecode.com/ -->    <g>     <title>Layer 1</title>     <path fill="#aaff56" fill-rule="evenodd" stroke="#008c00" stroke-width="3.75" stroke-linejoin="round" stroke-linecap="round" id="svg_43" d="m98.02173,199.93579c1.2576,-23.53561 -15.83954,-41.25836 -37.59734,-42.61978c-21.75781,-1.36035 -40.43779,16.63773 -41.69539,40.17334c-0.09697,1.81488 -0.09293,0.87192 0.01314,2.6868l39.40343,-0.2218l39.87616,-0.01855l0,0l0,0z"></path>     <g id="svg_39">      <path fill="#ffd4aa" fill-rule="evenodd" stroke="#854b12" stroke-width="3.75" stroke-linejoin="round" stroke-linecap="round" id="svg_42" d="m78.80554,146.56812a21.23345,26.32057 0 1 0-42.46693,0a21.23345,26.32057 0 1 042.46693,0z"></path>      <path fill="#854b12" fill-rule="evenodd" stroke-width="1pt" id="svg_41" d="m37.83022,137.62903c0,-1.11734 -1.72124,4.4697 5.85359,4.96574c7.57585,0.49715 15.03653,-12.53909 21.00426,-10.55266c5.96877,1.98642 8.72331,10.18117 12.16579,4.96619c1.72226,-4.22122 -10.21423,-14.52599 -10.21423,-14.52599c0,0 -5.50916,-2.48314 -8.95264,-2.48314c-3.44345,0 -9.87079,2.7314 -11.47789,3.97298c-1.60709,1.24156 -5.27985,6.20764 -5.27985,6.20764l-3.09903,7.44923l0,0l0,0l0,0l0,0l0,0z"></path>      <path fill="#ffffff" fill-rule="evenodd" stroke-width="1pt" id="svg_40" d="m38.80397,137.27238c-0.2899,1.84341 1.76163,3.0934 3.11618,3.60365c2.41013,0.74519 4.62128,1.55702 14.69109,-7.44943c8.91422,-9.39699 3.20102,-13.0873 -3.60207,-11.99693c-5.50916,0.99321 -12.61832,7.92169 -14.2052,15.84261l0,0.00011l0,0l0,0l0,0l0,0z" opacity="0.35"></path>     </g>    </g>   </g>   <g id="svg_78">    <g>     <path fill="none" stroke="#007f3f" d="m115.69226,257.25421l71.95944,-0.66183l0,7.31467l33.28165,-17.20676l-34.53931,-19.36664l0.62881,8.28992l-71.68951,0.48764l0.13425,20.96878l0.22467,0.17422z" id="svg_77" stroke-width="5"></path>     <title>Layer 1</title>    </g>   </g>  </g> </svg><p><br> </p>', 1, NULL, 0, 'imported', NULL, 'CC BY', 'original', NULL, NULL),
(48, 48, '2013-08-29 17:47:04', '<h2>Inline Frames</h2><p>   &nbsp;You can embed inline frames into your slides. Using this approach, you can run online Web applications within your slides.<br></p> <p>   For example (embedding a video): </p> <p> </p> <textarea style="" class="code passive-code" mode="htmlmixed">  &lt;iframe width="560" height="315" src="http://www.youtube.com/embed/ItN0_13Ick0?list=PL0A114817816A7849" frameborder="0" allowfullscreen&gt;&lt;/iframe&gt; </textarea> <iframe src="http://www.youtube.com/embed/6SlCLaFylG8?list=PL0A114817816A7849" allowfullscreen="" frameborder="0" height="315" width="560"></iframe> * Notice: the slide containg the iframe tag should not be the first slide of your deck', 1, NULL, 0, 'imported', NULL, 'CC BY', 'original', NULL, NULL),
(49, 49, '2013-08-29 17:47:04', '<h2>Progressive display of slides</h2><p>   SlideWiki supports the progressive display of slides, just surround the content to be displayed progressively with additional HTML block elements (e.g. DIV) having the attribute class="inslide" </p> <pre>Content to display first &lt;div class="inslide"&gt; Content to display second &lt;div class="inslide"&gt; Content to display third &lt;/div&gt; &lt;/div&gt; </pre> <p>   For example: </p> <li class="inslide">   Content to display first </li> <li class="inslide">   Content to display second </li> <li class="inslide">   Content to display third </li> <p> </p>', 1, NULL, 0, 'imported', NULL, 'CC BY', 'original', NULL, NULL),
(50, 50, '2013-08-29 17:47:04', '<h2>Animations and Effects</h2><p>   SlideWiki supports different types of animations and effects within slides. </p> <p>   For example: </p> <ul>   <li class="effect-shake"> Shake (use class "effect-shake") </li>   <li class="effect-bounce">     <b>       Bounce      </b> (use class "effect-bounce") </li>   <li class="effect-pulsate"> Pulsate (use class "effect-pulsate") </li>     <li class="effect-highlight"> Highlight (use class "effect-highlight") </li> </ul>', 1, NULL, 0, 'imported', NULL, 'CC BY', 'original', NULL, NULL),
(51, 51, '2013-08-29 17:47:04', '<h2>Styling</h2><ul><li><h4>SlideWiki employs <a style="" target="_blank" href="http://slidewiki.aksw.org/?url=main/deck&amp;deck=55#tree-55-slide-265-0-view" class="aloha aloha-link-text">Saas&nbsp;</a>for creating dynamic styles for the presentations.</h4><ul><li>Sass is an extension of CSS3, adding <a class="aloha-link-text" href="http://sass-lang.com/#nesting">nested rules</a>, <a class="aloha-link-text" href="http://sass-lang.com/#variables">variables</a>, <a href="http://sass-lang.com/#mixins">mixins</a>, <a class="aloha-link-text" href="http://sass-lang.com/#extend">selector inheritance</a>, and <a href="http://sass-lang.com/docs/yardoc/file.SASS_REFERENCE.html" class="aloha-link-text">more</a>.</li></ul></li><li><h4>To create a new theme for your presentation, you can use the following predefined CSS classes:</h4><p><br class="aloha-end-br"></p><p style="text-align: center;">.first-slide<br><br>.first-sub-slide<br><br>.slide-header<br><br>.slide-title<br><br>.slide-body<br><br>.slide-metadata<br><br>.slide-footer<br><br>.slide-footer-text</p><p style="text-align: center;">...</p></li></ul>', 1, NULL, 0, 'imported', NULL, 'CC BY', 'original', NULL, NULL),
(52, 52, '2013-08-29 17:47:04', '<h2>Transitions</h2><h5>Besides the four default transitions, SlideWiki supports creating <a style="" target="_blank" href="https://github.com/bartaz/impress.js/" class="aloha">impress.js</a> transitions.</h5><p><br class="aloha-end-br"></p><p>* To create your customized transitions, click on the Edit button next to the transition drop-down menu and then click on the&nbsp;<b>Builder4Impress </b>link on top.<br class="aloha-end-br"></p><p><br class="aloha-end-br"></p><p><br class="aloha-end-br"></p>', 1, NULL, 0, 'imported', NULL, 'CC BY', 'original', NULL, NULL),
(53, 53, '2013-08-29 17:47:29', '<h2>new slide</h2>', 1, NULL, 0, NULL, NULL, 'CC BY', 'original', NULL, NULL);
INSERT INTO `slide_revision` (`id`, `slide`, `timestamp`, `content`, `user_id`, `based_on`, `popularity`, `comment`, `note`, `license`, `translation_status`, `translator_id`, `translated_from_revision`) VALUES
(54, 54, '2013-08-29 17:47:29', '<h2>Introduction</h2><p style="text-align: justify;">   <b>     SlideWiki   </b>   aims to exploit the wisdom, creativity and productivity of the crowd for the    <i>     creation of rich, deep-semantically structured E-Learning content   </i>   . Users can create and collaborate on educational slides, diagrams, assessments and arrange slides in presentations. Presentations can be organized hierarchically, so as to structure them reasonably according to their content. </p> <p style="text-align: justify;">   SlideWiki empowers communities of instructors,    teachers, lecturers, academics to create, share and re-use sophisticated   educational content in a truly collaborative way. In addition to    importing PowerPoint presentations, it supports authoring of interactive   online slides using HTML and LaTeX. Slides and their containers (called decks), are versioned, thereby enabling change tracking. Users can create   their own themes on top of existing themes or re-use other''s themes. </p> <p style="text-align: justify;">   *    <b>     Video tutorials   </b>   about the different features of SlideWiki are available    <a style="" target="_blank" href="http://www.youtube.com/playlist?list=PL0A114817816A7849" class="aloha aloha-link-text">     here   </a>   .   <br class="aloha-end-br"> </p> <p style="text-align: justify;">   SlideWiki is developed and maintained by    <a class="aloha-link-text" href="http://aksw.org/">     AKSW research group   </a>   at    <a class="aloha-link-text" href="http://www.uni-leipzig.de/">     University of Leipzig   </a>   . </p> <div class="aloha-table-wrapper" contenteditable="false">        <table id="828e7bbc-d8cc-5783-c7a3-fca36c9a65e3" align="center" border="0">       <tbody>                  <tr class="aloha-table-selectcolumn" style="height: 10px;">                      <td class="aloha-table-leftuppercorner">                                       <div style="width: 25px; height: 12px;" class="aloha-wai-red">               </div>             </td>           <td>                                       &nbsp;             </td>           <td>                                       &nbsp;             </td>           <td>                                       &nbsp;             </td>         </tr>         <tr>                                 <td>                                       <div class="aloha-table-cell-editable" contenteditable="true">                 <a style="" target="_blank" href="http://aksw.org" class="aloha aloha-link-text">                   <img src="./upload/media/images/1\\6.png" height="66&quot;" width="152">                 </a>               </div>             </td>           <td>                                       <div class="aloha-table-cell-editable" contenteditable="true">                 <a target="_self" class="aloha-link-text" href="http://uni-leipzig.de">                   <img src="./upload/media/images/1\\7.jpg">                 </a>               </div>             </td>           <td>                                       <div class="aloha-table-cell-editable" contenteditable="true">                 <a class="aloha-link-text" target="_self" href="http://infai.org">                   <img src="./upload/media/images/1\\8.png">                 </a>               </div>             </td>         </tr>       </tbody>     </table>    </div>', 1, NULL, 0, 'imported', NULL, 'CC BY', 'original', NULL, NULL),
(55, 55, '2013-08-29 17:47:29', '<h2>Motivation</h2><div class="aloha-table-wrapper" contenteditable="false">   <table id="5b480726-dc2d-0515-b99b-e6948a6e6bf4">     <tbody>       <tr class="inslide">                  <td style="vertical-align:middle;">           <div class="aloha-table-cell-editable" contenteditable="true">             <h4>               How can we collaboratively write texts?              </h4>           </div>         </td>         <td style="vertical-align:middle;">           <div class="aloha-table-cell-editable" contenteditable="true">             <img src="./upload/media/images/1\\9.jpg" height="222" width="178">           </div>         </td>       </tr>       <tr class="inslide">                  <td style="vertical-align:middle;">           <div class="aloha-table-cell-editable" contenteditable="true">             <h4>               How can we collaboratively create the largest multilingual encyclopedia?             </h4>           </div>         </td>         <td style="vertical-align:middle;">           <div class="aloha-table-cell-editable" contenteditable="true">             <img class="effect-bounce" src="./upload/media/images/1\\10.png" height="225" width="185">           </div>         </td>       </tr>       <tr class="inslide">                  <td style="vertical-align:middle;">           <div class="aloha-table-cell-editable" contenteditable="true">             <h4>               How can we create a crowd-sourced map of the world?             </h4>           </div>         </td>         <td style="vertical-align:middle;">           <div class="aloha-table-cell-editable" contenteditable="true">             <img src="./upload/media/images/1\\11.jpg" height="85" width="258">           </div>         </td>       </tr>     </tbody>   </table> </div> <h3>   <div style="text-align:center;color:#750062;font-weight:bold;-moz-border-radius: 7px;padding: 1px;border-radius: 3px;border: 3px outset rgba(0, 0.2, 0, 0.6);box-shadow: 5px 5px 5px #888888;" class="inslide">     How can we collaboratively create, share and reuse      <span style="color:#960028;">       <b>         rich educational content       </b>     </span>     in hundreds of languages???   </div> </h3>', 1, NULL, 0, 'imported', NULL, 'CC BY', 'original', NULL, NULL),
(56, 56, '2013-08-29 17:47:29', '<h2>Feature Overview</h2><p>   SlideWiki allows to create richly structured presentations comprising slides, self-test questionnaires, illustrations etc. Features include: </p> <ul>   <li>     WYSIWYG slide authoring   </li>   <li>     Logical slide and deck representation   </li>   <li>     LaTeX/MathML integration   </li>   <li>     Multilingual decks / semi-automatic translation in 50+ languages   </li>   <li>     PowerPoint/HTML import   </li>   <li>     Source code highlighting within slides   </li>   <li>     Dynamic CSS themability and transitions   </li>   <li>     Social networking activities   </li>   <li>     Full revisioning and branching of slides and decks    </li>   <li>     E-Learning with self-assessment questionnaires    </li>   <li>     Source, citation and attribution tracking    </li> </ul>     All content in SlideWiki is licensed under CC-BY-SA.', 1, NULL, 0, 'imported', NULL, 'CC BY', 'original', NULL, NULL),
(57, 57, '2013-08-29 17:47:29', '<h2>Cite SlideWiki</h2><p>SlideWiki can be cited as follows:</p><p><b><i>SlideWiki: Elicitation and Sharing of Corporate Knowledge using Presentations</i></b><br>Ali Khalili, Sören Auer, Darya Tarasowa, and Ivan Ermilov. Proceedings of 18th International Conference on Knowledge Engineering and Knowledge Management (EKAW2012), Springer LNCS 7603, 2012.<br class="aloha-end-br"></p><p>Different citation formats can be found at <a style="" target="_blank" href="http://www.bibsonomy.org/bibtex/2f60879838833c98799b73f424bd35228/aksw" class="aloha aloha-link-text">Bibsonomy</a>.<br class="aloha-end-br"></p><pre>@inproceedings{khalilii-2012-ekaw,<br>&nbsp; author = {Khalili, Ali and Auer, S{\\"o}ren and Tarasowa, Darya and Ermilov, Ivan},<br>&nbsp; booktitle = {Proceedings of 18th International Conference on Knowledge Engineering and Knowledge Management (EKAW 2012)},<br>&nbsp; note = {16% acceptance rate, nominated for the best-paper award},<br>&nbsp; publisher = {Springer},<br>&nbsp; series = {Lecture Notes in Computer Science (LNCS) 7603},<br>&nbsp; title = {SlideWiki: Elicitation and Sharing of Corporate Knowledge using Presentations},<br>&nbsp; url = {http://svn.aksw.org/papers/2012/EKAW_SlideWiki/camera-ready/public.pdf},<br>&nbsp; year = 2012<br>}<br class="aloha-end-br"></pre>', 1, NULL, 0, 'imported', NULL, 'CC BY', 'original', NULL, NULL),
(58, 58, '2013-08-29 17:47:29', '<h2>How is SlideWiki different?</h2><p>   There are a number of online tools for presentations, such as Google Docs Presentations, Prezi, SlideShare. SlideWiki differs quite a lot from these due to its focus on: </p> <ul>   <li>     <b>       E-learning     </b>     - you can add questions to slides and thus compose comprehensive self-assessment tests for learners   </li>   <li>     <b>       Collaboration     </b>     - SlideWiki aims at empowering whole communities to create presentations collaboratively   </li>   <li>     <b>       Translation      </b>     - with SlideWiki content can be easily translated in more than 50 languages     <br>   </li> </ul> <p>   No other tool provides this twist and thus SlideWiki offers a unique feature set. </p> <p>   Other than most OpenCourseWare projects SlideWiki promotes truly    <b>     OPEN   </b>   CourseWare </p> <ul>   <li>     the vast majority of OpenCourseWare initiatives publishes their content only under restrictive CC-BY-NC (no commercial reuse allowed) or CC-NC-ND (no commercial reuse and no derivations)   </li>   <li>     CC-BY-NC and CC-NC-ND are      <b>       no      </b>     open licenses according to the      <a href="http://opendefinition.org" class="aloha-link-text" style="">       open definition     </a>   </li> </ul>', 1, NULL, 0, 'imported', NULL, 'CC BY', 'original', NULL, NULL),
(59, 59, '2013-08-29 17:47:29', '<h2>Status and Future Plans</h2><p>SlideWiki is <i>currently in a productive beta test mode</i> - creating comprehensive, e-learning content works, but there might be occasional problems with certain features on certain platforms</p><p>Please use one of the following ways to report problems:</p><ul><li>the Feedback button on the left</li><li>our <a style="" href="https://bitbucket.org/yamalightz/slidewiki/issues" class="">Issue tracker </a></li><li>our <a style="" href="https://groups.google.com/d/forum/slidewiki" class="aloha-link-text">Google group</a> </li></ul><p>We have implemented a sophisticated backup strategy, but still recommend you to export and download your content from time to time</p><p>In the medium to long future we plan to:</p><ul><li><i>support more interactive learning content</i>, such as games, learning apps,&nbsp;synchronization&nbsp;with video</li><li><i>substantially increase the content base</i> particularly for school and undergraduate learners as well as the availability of this content in smaller languages and developing countries</li></ul>', 1, NULL, 0, 'imported', NULL, 'CC BY', 'original', NULL, NULL),
(60, 60, '2013-08-29 17:47:29', '<h2>Questions & Contact</h2><p style="text-align: center;">   <a href="http://slidewiki.org" class="aloha-link-text" target="_blank" style=""> <svg id="svg0" width="182" height="64" xmlns="http://www.w3.org/2000/svg">   <g>     <title>       Layer 1     </title>     <path fill="#E75113" d="m130.68832,43.25862c0,-0.636 -0.52002,-1.155 -1.155,-1.155h-27.70802c-0.63501,0 -1.155,0.52 -1.155,1.155v19.41701c0,0.636 0.51999,1.155 1.155,1.155h27.70802c0.63498,0 1.155,-0.52 1.155,-1.155v-19.41701l0,0z">     </path>     <path fill="#DAE3E8" d="m0.07532,46.48262c0,-0.48999 0.401,-0.89099 0.892,-0.89099h4.76599c0.49101,0 0.892,0.39999 0.892,0.89099v3.11501c0,0.49001 -0.40099,0.89101 -0.892,0.89101h-4.76599c-0.491,0 -0.892,-0.40001 -0.892,-0.89101v-3.11501l0,0z">     </path>     <path fill="#C4D2DA" d="m11.63231,46.51163c0,-0.506 0.414,-0.92 0.92,-0.92h6.793c0.50601,0 0.91901,0.414 0.91901,0.92v4.297c0,0.506 -0.414,0.92 -0.91901,0.92h-6.793c-0.506,0 -0.92,-0.414 -0.92,-0.92v-4.297l0,0z">     </path>     <path fill="#AFC2CB" d="m25.27332,46.54062c0,-0.521 0.42599,-0.94899 0.94899,-0.94899h8.81801c0.522,0 0.94901,0.42799 0.94901,0.94899v5.79901c0,0.521 -0.427,0.94499 -0.94901,0.94499h-8.81801c-0.52199,0 -0.94899,-0.424 -0.94899,-0.94499v-5.79901l0,0z">     </path>     <path fill="#9BB1BC" d="m40.99831,46.56862c0,-0.53699 0.43901,-0.97699 0.97701,-0.97699h10.845c0.53699,0 0.97601,0.439 0.97601,0.97699v6.89201c0,0.53499 -0.43903,0.97499 -0.97601,0.97499h-10.84599c-0.53801,0 -0.97701,-0.439 -0.97701,-0.97499v-6.89201l0.00099,0z">     </path>     <path fill="#87A0AD" d="m58.8053,46.59763c0,-0.55299 0.45203,-1.006 1.00601,-1.006h12.871c0.55199,0 1.005,0.453 1.005,1.006v8.39c0,0.55499 -0.453,1.006 -1.005,1.006h-12.871c-0.55399,0 -1.00601,-0.451 -1.00601,-1.006v-8.39l0,0z">     </path>     <path fill="#73909E" d="m78.69632,46.62462c0,-0.56799 0.465,-1.03299 1.034,-1.03299h14.898c0.56699,0 1.033,0.465 1.033,1.03299v9.89401c0,0.56799 -0.465,1.03299 -1.033,1.03299h-14.898c-0.569,0 -1.034,-0.465 -1.034,-1.03299v-9.89401l0,0z">     </path>     <path fill="#DAE3E8" d="m181.14932,46.49962c0,-0.5 -0.40802,-0.90799 -0.90701,-0.90799h-4.84399c-0.5,0 -0.90701,0.40799 -0.90701,0.90799v3.164c0,0.496 0.40701,0.90601 0.90701,0.90601h4.84399c0.49899,0 0.90701,-0.41 0.90701,-0.90601v-3.164l0,0z">     </path>     <path fill="#A5B9C4" d="m157.67133,46.56262c0,-0.535 0.43597,-0.97099 0.97,-0.97099h9.87097c0.53403,0 0.97101,0.43599 0.97101,0.97099v6.16501c0,0.53299 -0.43698,0.96899 -0.97101,0.96899h-9.87097c-0.53403,0 -0.97,-0.436 -0.97,-0.96899v-6.16501l0,0z">     </path>     <path fill="#73909E" d="m135.69733,46.62462c0,-0.56799 0.465,-1.03299 1.034,-1.03299h14.89798c0.56703,0 1.03302,0.465 1.03302,1.03299v9.89401c0,0.56799 -0.465,1.03299 -1.03302,1.03299h-14.89798c-0.569,0 -1.034,-0.465 -1.034,-1.03299v-9.89401l0,0z">     </path>     <g>       <path fill="#547483" d="m-0.00169,28.4236c0,-0.646 0.323,-1.434 0.97,-2.361c0.646,-0.928 1.19499,-1.391 1.64499,-1.391c0.168,0 0.53401,0.154 1.09601,0.463c1.743,0.984 3.44299,1.477 5.103,1.477c2.64199,0 3.96399,-1.025 3.96399,-3.078c0,-0.9 -0.421,-1.658 -1.265,-2.277c-0.844,-0.619 -1.863,-1.16 -3.05799,-1.623c-1.19501,-0.465 -2.382,-0.998 -3.563,-1.604c-1.181,-0.604 -2.19301,-1.539 -3.036,-2.805c-0.843,-1.264 -1.265,-2.846 -1.265,-4.744c0,-1.89598 0.506,-3.52098 1.51799,-4.86898c1.827,-2.44699 4.653,-3.67 8.477,-3.67c2.136,0 3.936,0.311 5.397,0.92801c1.461,0.619 2.193,1.293 2.193,2.02299c0,0.619 -0.268,1.38701 -0.801,2.299c-0.534,0.914 -1.041,1.371 -1.518,1.371c-0.113,0 -0.366,-0.09799 -0.759,-0.295c-1.125,-0.506 -2.424,-0.75999 -3.9,-0.75999s-2.50199,0.254 -3.07898,0.75999c-0.57701,0.506 -0.86401,1.13901 -0.86401,1.89598c0,0.76 0.42101,1.434 1.265,2.025c0.843,0.59 1.85499,1.111 3.03599,1.561s2.368,0.977 3.563,1.58c1.194,0.605 2.214,1.539 3.057,2.805s1.265,2.777 1.265,4.533c0,1.758 -0.274,3.262 -0.822,4.512c-0.548,1.252 -1.301,2.229 -2.256,2.932c-1.855,1.35 -4.132,2.023 -6.83199,2.023c-2.69899,0 -4.96199,-0.406 -6.789,-1.223c-1.82898,-0.814 -2.74199,-1.644 -2.74199,-2.488l-0.00001,0z">       </path>       <path fill="#547483" d="m31.8363,27.2016l1.139,-0.168c0.365,0 0.675,0.414 0.928,1.244s0.379,1.426 0.379,1.791c0,1.379 -1.349,2.066 -4.048,2.066c-4.105,0 -6.157,-2.277 -6.157,-6.83v-23.95296c0,-0.90001 0.843,-1.35001 2.53,-1.35001h1.181c1.687,0 2.53,0.44901 2.53,1.35001v24.03696c0,1.209 0.506,1.813 1.518,1.813l0,0z">       </path>       <path fill="#547483" d="m41.07132,6.11763c-1.68701,0 -2.53001,-0.44901 -2.53001,-1.35001v-3.416c0,-0.89999 0.843,-1.35001 2.53001,-1.35001h1.181c1.687,0 2.53,0.44901 2.53,1.35001v3.416c0,0.89999 -0.843,1.35001 -2.53,1.35001h-1.181l0,0zm-2.53001,24.416v-19.52501c0,-0.89799 0.843,-1.34999 2.53001,-1.34999h1.181c1.687,0 2.53,0.45099 2.53,1.34999v19.52501c0,0.89999 -0.843,1.34999 -2.53,1.34999h-1.181c-1.68701,-0.00099 -2.53001,-0.45 -2.53001,-1.34999z">       </path>       <path fill="#547483" d="m58.1503,32.1346c-2.333,0 -4.231,-1.004 -5.693,-3.014c-1.462,-2.01 -2.193,-4.779 -2.193,-8.309c0,-3.527 0.78,-6.311 2.341,-8.35c1.56,-2.037 3.746,-3.05697 6.557,-3.05697c1.659,0 3.092,0.43599 4.301,1.30697v-9.36097c0,-0.90001 0.844,-1.35001 2.53,-1.35001h1.181c1.687,0 2.53,0.44901 2.53,1.35001v23.02497c0,1.742 0.084,3.205 0.253,4.385l0.253,1.729c0,0.451 -0.569,0.787 -1.708,1.012c-1.139,0.227 -1.989,0.338 -2.55099,0.338c-0.563,0 -0.93501,-0.055 -1.118,-0.168c-0.183,-0.111 -0.331,-0.295 -0.443,-0.549c-0.112,-0.252 -0.197,-0.463 -0.253,-0.633c-0.057,-0.168 -0.12,-0.441 -0.189,-0.822c-0.071,-0.379 -0.12,-0.611 -0.148,-0.695c-0.506,0.928 -1.258,1.688 -2.256,2.277c-0.997,0.59 -2.129,0.885 -3.394,0.885l0,0zm1.856,-5.101c1.349,0 2.501,-0.83 3.458,-2.488v-9.404c-0.956,-0.533 -1.939,-0.801 -2.952,-0.801c-2.615,0 -3.922,2.115 -3.922,6.346c0,4.231 1.139,6.347 3.416,6.347z">       </path>       <path fill="#547483" d="m77.8643,29.1616c-1.813,-1.982 -2.72,-4.842 -2.72,-8.582c0,-3.738 0.907,-6.535 2.72,-8.391c1.813,-1.855 4.30099,-2.78297 7.464,-2.78297c3.163,0 5.482,1.01197 6.958,3.03497c1.476,2.025 2.214,4.639 2.214,7.844c0,0.338 -0.28899,0.838 -0.865,1.498c-0.577,0.66 -1.005,0.99 -1.286,0.99h-10.753c0.141,1.604 0.618,2.742 1.434,3.416s1.856,1.012 3.121,1.012c1.265,0 2.474,-0.217 3.627,-0.652c1.152,-0.436 1.743,-0.654 1.771,-0.654c0.422,0 0.892,0.414 1.413,1.244c0.52,0.83 0.78,1.482 0.78,1.961c0,0.928 -0.87901,1.666 -2.636,2.213c-1.757,0.549 -3.409,0.822 -4.955,0.822c-3.711,0 -6.474,-0.99 -8.28699,-2.973l0,0zm10.564,-10.562c0,-1.293 -0.253,-2.326 -0.759,-3.1c-0.506,-0.773 -1.265,-1.16 -2.27699,-1.16c-2.081,0 -3.346,1.42 -3.79501,4.26h6.831l0,0l0,0z">       </path>       <path fill="#547483" d="m97.28333,3.29062c0,-0.73001 0.87099,-1.09601 2.61398,-1.09601h1.09702c1.68701,0 2.62799,0.436 2.82501,1.30701l3.16299,13.578c0.056,0.19699 0.492,2.22299 1.30798,6.07199c0.168,-1.123 0.646,-3.146 1.43401,-6.07199l3.45798,-14c0.14001,-0.59001 0.91302,-0.88501 2.319,-0.88501h1.603c1.405,0 2.17801,0.295 2.319,0.88501l3.332,14c0.47803,2.05299 0.95502,4.17599 1.43402,6.36899c0.19598,-0.81599 0.457,-1.961 0.78,-3.43799c0.323,-1.47701 0.54099,-2.453 0.65298,-2.93201l3.29002,-13.578c0.19601,-0.871 1.13901,-1.30699 2.82501,-1.30699h0.46399c1.74301,0 2.61499,0.36499 2.61499,1.09599c0,0.084 -0.02798,0.295 -0.08398,0.633l-6.87399,27.07201c-0.16901,0.592 -0.94202,0.88701 -2.319,0.88701h-3.07901c-1.43399,0 -2.20801,-0.29501 -2.319,-0.88701l-4.133,-17.457l-4.30099,17.457c-0.168,0.592 -0.94202,0.88701 -2.31899,0.88701h-3.03601c-1.43399,0 -2.20802,-0.29501 -2.319,-0.88701l-6.66299,-27.07201c-0.05801,-0.16698 -0.08701,-0.37798 -0.08701,-0.63199z">       </path>       <path fill="#547483" d="m141.35031,6.11763c-1.68701,0 -2.53,-0.44901 -2.53,-1.35001v-3.416c0,-0.89999 0.84299,-1.35001 2.53,-1.35001h1.181c1.68701,0 2.53,0.44901 2.53,1.35001v3.416c0,0.89999 -0.84299,1.35001 -2.53,1.35001h-1.181l0,0zm-2.53,24.416v-19.52501c0,-0.89799 0.84299,-1.34999 2.53,-1.34999h1.181c1.68701,0 2.53,0.45099 2.53,1.34999v19.52501c0,0.89999 -0.84299,1.34999 -2.53,1.34999h-1.181c-1.686,-0.00099 -2.53,-0.45 -2.53,-1.34999z">       </path>       <path fill="#547483" d="m152.399,30.5336v-29.18196c0,-0.90001 0.843,-1.35001 2.53,-1.35001h1.181c1.687,0 2.53,0.44901 2.53,1.35001v16.69896l0.168,0.043l5.103,-7.633c0.36501,-0.53497 1.22301,-0.80296 2.57201,-0.80296h1.56c1.57401,0 2.362,0.211 2.362,0.63296c0,0.227 -0.12599,0.506 -0.38,0.844l-5.86099,8.35l6.87399,10.881c0.22501,0.393 0.33701,0.688 0.33701,0.8851c0,0.4219 -0.80099,0.6329 -2.40401,0.6329h-1.771c-1.37799,0 -2.22099,-0.268 -2.53,-0.8009l-5.862,-9.6991l-0.168,0.0411v9.1089c0,0.9 -0.843,1.35 -2.53,1.35h-1.181c-1.687,-0.001 -2.53,-0.45 -2.53,-1.35l0,0z">       </path>       <path fill="#547483" d="m178.0813,6.11763c-1.68799,0 -2.53,-0.44901 -2.53,-1.35001v-3.416c0,-0.89999 0.84302,-1.35001 2.53,-1.35001h1.181c1.68701,0 2.53,0.44901 2.53,1.35001v3.416c0,0.89999 -0.84399,1.35001 -2.53,1.35001h-1.181l0,0zm-2.53098,24.416v-19.52501c0,-0.89799 0.84299,-1.34999 2.53,-1.34999h1.181c1.68698,0 2.53,0.45099 2.53,1.34999v19.52501c0,0.89999 -0.84399,1.34999 -2.53,1.34999h-1.181c-1.68701,-0.00099 -2.53,-0.45 -2.53,-1.34999z">       </path>     </g>   </g> </svg>   </a>   <br class="aloha-end-br"> </p> <p> </p> <img src="http://slidewiki.aksw.org/?url=ajax/getAvatarSrc&amp;id=2" style=""> <p>   Ali Khalili   (   <a href="mailto:khalili@informatik.uni-leipzig.de" class="aloha aloha-link-text" target="_blank" style="">     khalili@informatik.uni-leipzig.de   </a>   ) </p> <img src="http://wiki.aksw.org/images/jpegPhoto.php?name=sn&amp;value=Tarasowa" height="90" width="75"> <p>   Darya Tarasowa   (   <a href="mailto:tarasowa@informatik.uni-leipzig.de" class="aloha aloha-link-text" target="_blank" style="">     tarasowa@informatik.uni-leipzig.de   </a>   )   <br class="aloha-end-br"> </p> <img src="http://slidewiki.aksw.org/?url=ajax/getAvatarSrc&amp;id=1" style=""> <p>   <a href="http://www.informatik.uni-leipzig.de/~auer/" class="" style="">     Sören Auer   </a>   (   <a href="mailto:auer@informatik.uni-leipzig.de" class="aloha" target="_blank">     auer@informatik.uni-leipzig.de   </a>   ) </p>', 1, NULL, 0, 'imported', NULL, 'CC BY', 'original', NULL, NULL),
(61, 61, '2013-08-29 17:47:29', '<h2>Supporting organizations</h2><div class="aloha-table-wrapper" contenteditable="false">   <table id="fd5b8cbd-6190-9947-bf81-ba3ec673b45e" class="aloha-table" contenteditable="false" style="">     <tbody>       <tr class="aloha-table-selectcolumn" style="height: 10px;">         <td class="aloha-table-leftuppercorner">           <div class="aloha-wai-red" style="width: 25px; height: 12px;">           </div>         </td>         <td>           &nbsp;         </td>         <td>           &nbsp;         </td>       </tr>       <tr>         <td class="aloha-table-selectrow" style="width: 10px;">           &nbsp;         </td>         <td class="">           <div contenteditable="true" class="aloha-table-cell-editable">             <div style="text-align: center;">               <a href="http://aksw.org" class="aloha-link-text" style="">                 Research group Agile Knowledge Engineering &amp; Semantic Web               </a>               <br>               <img src="http://aksw.org/extensions/site/sites/local/images/logo-aksw.png">             </div>             <div style="text-align: center;">               <a href="http://infai.org" class="aloha-link-text" style="">                 Institut für Angewandte Informatik e. V. an der Universität Leipzig               </a>               <br>               <img src="http://aksw.org/extensions/site/sites/local/images/logo-infai.png">             </div>             <div style="text-align: center;">               <a href="http://www.uni-leipzig.de" class="aloha-link-text" style="">                 Universität Leipzig               </a>               <br>               <img src="http://aksw.org/extensions/site/sites/local/images/logo-unileipzig.png">             </div>             <div style="text-align: center;">               <a href="http://www.iais.fraunhofer.de" class="aloha-link-text" style="">                 Fraunhofer IAIS               </a>               <br>               <img src="http://www.iais.fraunhofer.de/fileadmin/web2009/assets/img/iais_logo.gif">             </div>           </div>         </td>         <td>           <div contenteditable="true" class="aloha-table-cell-editable">             <div style="text-align: center;">               <a href="http://www.escience-sachsen.de/" class="aloha-link-text" style="">                 Escience Sachsen               </a>               <br>               <img src="./upload/media/images/1\\17.png">             </div>             <div style="text-align: center;">               <a href="http://eis.iai.uni-bonn.de/" class="aloha-link-text" style="">                 Enterprise Information Systems, Uni Bonn               </a>               <br>               <img src="http://www3.uni-bonn.de/logo.png">             </div>             <div style="text-align: center;">               <a href="http://www.igip.org" class="aloha-link-text" style="">                 International Society of                 Engineering                 Education               </a>               <br>               <img src="./upload/media/images/1\\18.gif">             </div>           </div>         </td>       </tr>     </tbody>   </table> </div>', 1, NULL, 0, 'imported', NULL, 'CC BY', 'original', NULL, NULL),
(62, 62, '2013-08-29 17:47:29', '<h2>Content Partner</h2><div>   <img src="./upload/media/images/1\\19.png" style="width:100px; height:100px;"> </div> <p style="text-align: center;">   <a href="http://sti2.org" class="" style="">     STI2 - Semantic Technologies Institute International   </a> </p>', 1, NULL, 0, 'imported', NULL, 'CC BY', 'original', NULL, NULL),
(63, 63, '2013-08-29 17:47:29', '<h2>Other Open Science Initiatives</h2><ul>   <li>     <a href="http://www.igip.org/igip/" class="aloha-link-text" style="">       Open Knowledge Foundation     </a>     with its working groups on      <a href="http://science.okfn.org/" class="" style="">       Open Science     </a>     and      <a href="http://access.okfn.org/" class="" style="">       Open Access     </a>   </li>   <li>     <a href="http://www.semantic-web-journal.net/" class="" style="">       Semantic Web Journal     </a>     with its open access and open review process   </li>   <li>     <a href="http://www.online-journals.org/" class="" style="">       OnlineJournals.ORG     </a>     an open-access publisher   </li>   <li>     <a href="http://bibsonomy.org" class="" style="">       BibSonomy      </a>     is a system for sharing bookmarks and lists of literature.   </li>   <li>     <a href="http://www.igip.org/" class="aloha-link-text">       International Society of       Engineering       Education     </a>   </li> </ul>', 1, NULL, 0, 'imported', NULL, 'CC BY', 'original', NULL, NULL),
(64, 55, '2013-08-29 17:52:35', '<h2>Motivation</h2><div class="aloha-table-wrapper" contenteditable="false">\n  <table id="5b480726-dc2d-0515-b99b-e6948a6e6bf4">\n    <tbody>\n      <tr class="inslide">\n        <td style="vertical-align:middle;">\n          <div class="aloha-table-cell-editable" contenteditable="true">\n            <h4>\n              How can we collaboratively write texts?              \n            </h4>\n          </div>\n        </td>\n        <td style="vertical-align:middle;">\n          <div class="aloha-table-cell-editable" contenteditable="true">\n            <img src="./upload/media/images/1/9.jpg" height="222" width="178">\n          </div>\n        </td>\n      </tr>\n      <tr class="inslide">\n        <td style="vertical-align:middle;">\n          <div class="aloha-table-cell-editable" contenteditable="true">\n            <h4>\n              How can we collaboratively create the largest multilingual encyclopedia?             \n            </h4>\n          </div>\n        </td>\n        <td style="vertical-align:middle;">\n          <div class="aloha-table-cell-editable" contenteditable="true">\n            <img class="effect-bounce" src="./upload/media/images/1/10.png" height="225" width="185">\n          </div>\n        </td>\n      </tr>\n      <tr class="inslide">\n        <td style="vertical-align:middle;">\n          <div class="aloha-table-cell-editable" contenteditable="true">\n            <h4>\n              How can we create a crowd-sourced map of the world?             \n            </h4>\n          </div>\n        </td>\n        <td style="vertical-align:middle;">\n          <div class="aloha-table-cell-editable" contenteditable="true">\n            <img src="./upload/media/images/1/11.jpg" height="85" width="258">\n          </div>\n        </td>\n      </tr>\n    </tbody>\n  </table>\n</div>\n<h3>\n  <div style="text-align:center;color:#750062;font-weight:bold;-moz-border-radius: 7px;padding: 1px;border-radius: 3px;border: 3px outset rgba(0, 0.2, 0, 0.6);box-shadow: 5px 5px 5px #888888;" class="inslide">\n    How can we collaboratively create, share and reuse      \n    <span style="color:#960028;">\n      <b>\n        rich educational content       \n      </b>\n    </span>\n    in hundreds of languages???   \n  </div>\n</h3>', 1, 55, 0, '', '', 'CC BY', 'original', NULL, NULL),
(65, 16, '2013-08-29 18:04:30', '<h2>How to translate your deck</h2><ol>\n  <li>\n    Make sure that you are logged in SlideWiki\n    <br class="aloha-end-br">\n  </li>\n  <li>\n    Select a deck or subdeck in the tree\n  </li>\n  <li>\n    Open the list of existing translations in the top-right corner (see screenshot below)\n    <br>\n  </li>\n  <li>\n    You can open existing translations of the deck by clicking on one of the languages\n  </li>\n  <li>\n    If the desired language is not available in the list or if the translation is \n    <span id="result_box" class="short_text" lang="en">\n      <span class="hps">\n        outdated\n      </span>\n    </span>\n    , use the translate button at the bottom of the list\n  </li>\n  <li>\n    SlideWiki will redirect you to the translated deck. However, the translation will not be ready momentarily, as it takes time to manage the translation process. Please, wait a few minutes and reload the page with the translated deck or return to it later.\n    <br>\n  </li>\n  <li>\n    After the translation is completed, you can revise it \n    <br>\n  </li>\n</ol>\n<div>\n  <img src="./upload/media/images/12.png">\n</div>', 1, 16, 0, '', '', 'CC BY', 'original', NULL, NULL),
(66, 16, '2013-08-29 18:04:50', '<h2>How to translate your deck</h2><ol>\n  <li>\n    Make sure that you are logged in SlideWiki\n    <br class="aloha-end-br">\n  </li>\n  <li>\n    Select a deck or subdeck in the tree\n  </li>\n  <li>\n    Open the list of existing translations in the top-right corner (see screenshot below)\n    <br>\n  </li>\n  <li>\n    You can open existing translations of the deck by clicking on one of the languages\n  </li>\n  <li>\n    If the desired language is not available in the list or if the translation is \n    <span id="result_box" class="short_text" lang="en">\n      <span class="hps">\n        outdated\n      </span>\n    </span>\n    , use the translate button at the bottom of the list\n  </li>\n  <li>\n    SlideWiki will redirect you to the translated deck. However, the translation will not be ready momentarily, as it takes time to manage the translation process. Please, wait a few minutes and reload the page with the translated deck or return to it later.\n    <br>\n  </li>\n  <li>\n    After the translation is completed, you can revise it \n    <br>\n  </li>\n</ol>\n<div>\n  <img src="./upload/media/images/1/2.png">\n</div>', 1, 65, 0, '', '', 'CC BY', 'original', NULL, NULL),
(67, 13, '2013-08-29 18:05:10', '<h2>Visibility, Licensing and Attribution</h2><p>\n  Users can set the visibility status of the deck. Invisible decks will not be listed in the SlideWiki home page.\n</p>\n<p>\n  SlideWiki is committed to open knowledge and giving credit to original authors and contributors. All contributions on SlideWiki (including images, styles etc.) have to be licensed under the\n  <a href="http://creativecommons.org/licenses/by/3.0/" class="aloha aloha-link-text" target="_blank" style="">\n    Creative Commons Attribution Share Alike license (CC-BY-SA)\n  </a>\n  .\n</p>\n<p>\n  SlideWiki tracks all contributors to a particular slide (respectively deck) and lists these contributors to acknowledge their contributions.\n</p>\n<p>\n  <br class="aloha-end-br">\n</p>\n<div>\n  <img src="./upload/media/images/1/1.png">\n</div>', 1, 13, 0, '', '', 'CC BY', 'original', NULL, NULL),
(68, 37, '2013-08-29 18:05:40', '<h2>Search and Replace</h2><ul>\n  <li>\n    &nbsp;Users can search within a deck content by clicking on the search icon on top of the presentation tree and entering their desirable search keywords. \n    <br>\n  </li>\n</ul>\n<div>\n  <img src="./upload/media/images/1/3.png">\n</div>\n<div>\n  <br class="aloha-end-br">\n</div>\n<ul>\n  <li>\n    Users (when logged in) can select "\n    <b>\n      Find and Replace\n    </b>\n    " feature from the context menu by right clicking on nodes in the tree.\n    <br>\n  </li>\n</ul>', 1, 37, 0, '', '', 'CC BY', 'original', NULL, NULL),
(69, 40, '2013-08-29 18:06:13', '<h2>Easy Question</h2><p>\n  <span style="font-size: 16px; line-height: 1.25;">\n    SlideWiki supports the assisted creation of questions\n  </span>\n  .\n</p>\n<p>\n  The respective tool "Easy Question" can be found in the editor menu.\n</p>\n<p>\n  The process includes these steps:\n</p>\n<ol>\n  <li>\n    Being logged in, click on the slide content to enable the editor menu\n  </li>\n  <li>\n    Select the fragment of the text, that includes the material for question and answer alternatives\n  </li>\n  <li>\n    In the editor menu switch to the "Easy Quest" tab and click the round yellow button with a question mark:\n  </li>\n</ol>\n<p>\n  <br class="aloha-end-br">\n</p>\n<div>\n  <img src="./upload/media/images/1/4.png">\n</div>', 1, 40, 0, '', '', 'CC BY', 'original', NULL, NULL),
(70, 41, '2013-08-29 18:06:32', '<h2>Easy Question result</h2><p>\n  After selecting a text fragment and clicking on the Easy Quest button, you are redirected to the question tab, and a new question is created from the selected text fragment.\n</p>\n<p>\n  Check and edit the question and alternatives, select the appropriate difficulty, add explanations, if necessary, and click the Save button to assign the question to the slide.\n</p>\n<p>\n  For example, the text fragment from the previous slide turned into following question:\n  <br>\n</p>\n<div>\n  <img src="./upload/media/images/1/5.png">\n</div>', 1, 41, 0, '', '', 'CC BY', 'original', NULL, NULL),
(71, 61, '2013-08-29 18:08:20', '<h2>Supporting organizations</h2><div class="aloha-table-wrapper" contenteditable="false">\n  <table id="fd5b8cbd-6190-9947-bf81-ba3ec673b45e" class="aloha-table" style="" contenteditable="false">\n    <tbody>\n      <tr class="aloha-table-selectcolumn" style="height: 10px;">\n        <td class="aloha-table-leftuppercorner">\n          <div class="aloha-wai-red" style="width: 25px; height: 12px;">\n          </div>\n        </td>\n        <td>\n          &nbsp;         \n        </td>\n        <td>\n          &nbsp;         \n        </td>\n      </tr>\n      <tr>\n        <td class="aloha-table-selectrow" style="width: 10px;">\n          &nbsp;         \n        </td>\n        <td class="">\n          <div class="aloha-table-cell-editable" contenteditable="true">\n            <div style="text-align: center;">\n              <a href="http://aksw.org" class="aloha-link-text" style="">\n                Research group Agile Knowledge Engineering &amp; Semantic Web               \n              </a>\n              <br>\n              <img src="http://aksw.org/extensions/site/sites/local/images/logo-aksw.png">\n            </div>\n            <div style="text-align: center;">\n              <a href="http://infai.org" class="aloha-link-text" style="">\n                Institut für Angewandte Informatik e. V. an der Universität Leipzig               \n              </a>\n              <br>\n              <img src="http://aksw.org/extensions/site/sites/local/images/logo-infai.png">\n            </div>\n            <div style="text-align: center;">\n              <a href="http://www.uni-leipzig.de" class="aloha-link-text" style="">\n                Universität Leipzig               \n              </a>\n              <br>\n              <img src="http://aksw.org/extensions/site/sites/local/images/logo-unileipzig.png">\n            </div>\n            <div style="text-align: center;">\n              <a href="http://www.iais.fraunhofer.de" class="aloha-link-text" style="">\n                Fraunhofer IAIS               \n              </a>\n              <br>\n              <img src="http://www.iais.fraunhofer.de/fileadmin/web2009/assets/img/iais_logo.gif">\n            </div>\n          </div>\n        </td>\n        <td>\n          <div class="aloha-table-cell-editable" contenteditable="true">\n            <div style="text-align: center;">\n              <a href="http://www.escience-sachsen.de/" class="aloha-link-text" style="">\n                Escience Sachsen               \n              </a>\n              <br>\n              <img src="./upload/media/images/1/17.png">\n            </div>\n            <div style="text-align: center;">\n              <a href="http://eis.iai.uni-bonn.de/" class="aloha-link-text" style="">\n                Enterprise Information Systems, Uni Bonn               \n              </a>\n              <br>\n              <img src="http://www3.uni-bonn.de/logo.png">\n            </div>\n            <div style="text-align: center;">\n              <a href="http://www.igip.org" class="aloha-link-text" style="">\n                International Society of                 Engineering                 Education               \n              </a>\n              <br>\n              <img src="./upload/media/images/1/18.gif">\n            </div>\n          </div>\n        </td>\n      </tr>\n    </tbody>\n  </table>\n</div>', 1, 61, 0, '', '', 'CC BY', 'original', NULL, NULL),
(72, 62, '2013-08-29 18:08:37', '<h2>Content Partner</h2><div>\n  <img src="./upload/media/images/1/19.png" style="width:100px; height:100px;">\n</div>\n<p style="text-align: center;">\n  <a href="http://sti2.org" class="" style="">\n    STI2 - Semantic Technologies Institute International   \n  </a>\n</p>', 1, 62, 0, '', '', 'CC BY', 'original', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `style`
--

CREATE TABLE IF NOT EXISTS `style` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `scss_varfunc` text COLLATE utf8_unicode_ci,
  `scss` text COLLATE utf8_unicode_ci,
  `css` text COLLATE utf8_unicode_ci NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `comment` text COLLATE utf8_unicode_ci,
  `based_on` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=34 ;

--
-- Dumping data for table `style`
--

INSERT INTO `style` (`id`, `user_id`, `name`, `scss_varfunc`, `scss`, `css`, `timestamp`, `comment`, `based_on`) VALUES
(3, 1, 'Neon', '', '.slide-footer{\r\n   z-index:999;\r\n   position:fixed;\r\n   left:0px;\r\n   bottom:0px;\r\n   height:30px;\r\n   width:100%;\r\n}\r\n	font-family: "Gill Sans", "Gill Sans MT", Calibri, sans-serif;\r\n	font-size:1.25em;\r\n	color:#aaa;\r\n	background:#000;\r\n	\r\n	.slide {\r\n		background:#000;\r\n		\r\n		h1 {\r\n			color:#0af;\r\n			font-weight:normal;\r\n			font-weight:100;\r\n			text-shadow:0 0 50px #0af, 0 0 3px #fff;\r\n		}\r\n\r\n		h2 {\r\n			color:#af0;\r\n			border-bottom-color:#ccc;\r\n			font-weight:normal;\r\n			font-weight:100;\r\n			text-shadow:0 0 15px #af0, 0 0 2px #fff;\r\n			border-bottom:1px solid #333;\r\n		}\r\n\r\n		h3 {\r\n			color:#fff;\r\n			font-weight:normal;\r\n			font-weight:100;\r\n			text-shadow:0 0 10px #fff, 0 0 2px #fff;\r\n		}\r\n\r\n		pre {\r\n			border-color:#333;\r\n\r\n			code {\r\n				color:#000;background-color: transparent;\r\n			}\r\n		}\r\n\r\n		code {\r\n			color:#000;background-color: transparent;\r\n		}\r\n\r\n		blockquote {\r\n			font-size:2em;\r\n			padding:1em 2em;\r\n			color:#fff;\r\n			border-left:5px solid #fff;\r\n\r\n			p {\r\n				margin:0;\r\n			}\r\n\r\n			cite {\r\n				font-size:.5em;\r\n				font-style:normal;\r\n				font-weight:normal;\r\n				font-weight:100;\r\n				color:#aaa;\r\n				text-shadow:0 0 15px #fff, 0 0 2px #fff;\r\n			}\r\n		}\r\n\r\n		::-moz-selection{ background:#a0f; }\r\n		::selection { background:#a0f; }\r\n\r\n		a {\r\n			&, &:hover, &:focus, &:active, &:visited {\r\n				color:#f0a;\r\n				text-decoration:none;\r\n			}\r\n\r\n			&:hover, &:focus {\r\n				text-decoration:underline;\r\n			}\r\n		}\r\n	}\r\n	\r\n	.deck-prev-link, .deck-next-link {\r\n		background:#f0a;\r\n		text-shadow:0 0 3px #fff;\r\n		\r\n		&, &:hover, &:focus, &:active, &:visited {\r\n			color:#fff;\r\n		}\r\n		\r\n		&:hover, &:focus {\r\n			text-decoration:none;\r\n			\r\n			.boxshadow & {\r\n				-webkit-box-shadow:0 0 20px #f0a, 0 0 5px #fff;\r\n				-moz-box-shadow:0 0 20px #f0a, 0 0 5px #fff;\r\n				box-shadow:0 0 20px #f0a, 0 0 5px #fff;\r\n			}\r\n		}\r\n	}\r\n	\r\n	> .slide {\r\n		.deck-before, .deck-previous {\r\n			opacity:0.4;\r\n		}\r\n	}\r\n	\r\n	.deck-status {\r\n		font-size:0.6666em;\r\n	}\r\n	\r\n	.goto-form {\r\n		background:#000;\r\n		border:1px solid #f0a;\r\n		\r\n		label {\r\n			color:#fff;\r\n		}\r\n	}\r\n	\r\n	&.deck-menu {\r\n		.slide {\r\n			background:#333;\r\n		}\r\n		\r\n		.deck-current {\r\n			background:#444;\r\n			\r\n			.boxshadow & {\r\n				background:#000;\r\n				-webkit-box-shadow:0 0 20px #f0a, 0 0 5px #fff;\r\n				-moz-box-shadow:0 0 20px #f0a, 0 0 5px #fff;\r\n				box-shadow:0 0 20px #f0a, 0 0 5px #fff;\r\n			}\r\n		}\r\n		\r\n		.no-touch & .slide:hover {\r\n			background:#444;\r\n		}\r\n		\r\n		.no-touch.boxshadow & .slide:hover {\r\n			background:#000;\r\n			-webkit-box-shadow:0 0 20px #f0a, 0 0 5px #fff;\r\n			-moz-box-shadow:0 0 20px #f0a, 0 0 5px #fff;\r\n			box-shadow:0 0 20px #f0a, 0 0 5px #fff;\r\n		}\r\n	}', '.deck-container {\r\n  font-family: "Gill Sans", "Gill Sans MT", Calibri, sans-serif;\r\n  font-size: 1.25em;\r\n  color: #aaaaaa;\r\n  background: black; }\r\n  .deck-container .slide-footer {\r\n    z-index: 999;\r\n    position: fixed;\r\n    left: 0px;\r\n    bottom: 0px;\r\n    height: 30px;\r\n    width: 100%; }\r\n  .deck-container .slide {\r\n    background: black; }\r\n    .deck-container .slide h1 {\r\n      color: #00aaff;\r\n      font-weight: normal;\r\n      font-weight: 100;\r\n      text-shadow: 0 0 50px #00aaff, 0 0 3px white; }\r\n    .deck-container .slide h2 {\r\n      color: #aaff00;\r\n      border-bottom-color: #cccccc;\r\n      font-weight: normal;\r\n      font-weight: 100;\r\n      text-shadow: 0 0 15px #aaff00, 0 0 2px white;\r\n      border-bottom: 1px solid #333333; }\r\n    .deck-container .slide h3 {\r\n      color: white;\r\n      font-weight: normal;\r\n      font-weight: 100;\r\n      text-shadow: 0 0 10px white, 0 0 2px white; }\r\n    .deck-container .slide pre {\r\n      border-color: #333333; }\r\n      .deck-container .slide pre code {\r\n        color: white;\r\n        background-color: transparent; }\r\n    .deck-container .slide code {\r\n      color: black;\r\n      background-color: transparent; }\r\n    .deck-container .slide blockquote {\r\n      font-size: 2em;\r\n      padding: 1em 2em;\r\n      color: white;\r\n      border-left: 5px solid white; }\r\n      .deck-container .slide blockquote cite {\r\n        font-size: 0.5em;\r\n        font-style: normal;\r\n        font-weight: normal;\r\n        font-weight: 100;\r\n        color: #aaaaaa;\r\n        text-shadow: 0 0 15px white, 0 0 2px white; }\r\n    .deck-container .slide ::-moz-selection {\r\n      background: #aa00ff; }\r\n    .deck-container .slide ::selection {\r\n      background: #aa00ff; }\r\n      .deck-container .slide a,\r\n      .deck-container .slide a:active,\r\n      .deck-container .slide a:focus,\r\n      .deck-container .slide a:hover,\r\n      .deck-container .slide a:visited {\r\n        color: #ff00aa;\r\n        text-decoration: none; }\r\n      .deck-container .slide a:focus,\r\n      .deck-container .slide a:hover {\r\n        text-decoration: underline; }\r\n  .deck-container .deck-next-link,\r\n  .deck-container .deck-prev-link {\r\n    background: #ff00aa;\r\n    text-shadow: 0 0 3px white; }\r\n    .deck-container .deck-next-link,\r\n    .deck-container .deck-next-link:active,\r\n    .deck-container .deck-next-link:focus,\r\n    .deck-container .deck-next-link:hover,\r\n    .deck-container .deck-next-link:visited,\r\n    .deck-container .deck-prev-link,\r\n    .deck-container .deck-prev-link:active,\r\n    .deck-container .deck-prev-link:focus,\r\n    .deck-container .deck-prev-link:hover,\r\n    .deck-container .deck-prev-link:visited {\r\n      color: white; }\r\n    .deck-container .deck-next-link:focus,\r\n    .deck-container .deck-next-link:hover,\r\n    .deck-container .deck-prev-link:focus,\r\n    .deck-container .deck-prev-link:hover {\r\n      text-decoration: none; }\r\n      .boxshadow .deck-container .deck-next-link:focus,\r\n      .boxshadow .deck-container .deck-next-link:hover,\r\n      .boxshadow .deck-container .deck-prev-link:focus,\r\n      .boxshadow .deck-container .deck-prev-link:hover {\r\n        -webkit-box-shadow: 0 0 20px #ff00aa, 0 0 5px white;\r\n        -moz-box-shadow: 0 0 20px #ff00aa, 0 0 5px white;\r\n        box-shadow: 0 0 20px #ff00aa, 0 0 5px white; }\r\n    .deck-container > .slide .deck-before,\r\n    .deck-container > .slide .deck-previous {\r\n      opacity: 0.4; }\r\n  .deck-container .deck-status {\r\n    font-size: 0.6666em; }\r\n  .deck-container .goto-form {\r\n    background: black;\r\n    border: 1px solid #ff00aa; }\r\n    .deck-container .goto-form label {\r\n      color: white; }\r\n    .deck-container.deck-menu .slide {\r\n      background: #333333; }\r\n    .deck-container.deck-menu .deck-current {\r\n      background: #444444; }\r\n      .boxshadow .deck-container.deck-menu .deck-current {\r\n        background: black;\r\n        -webkit-box-shadow: 0 0 20px #ff00aa, 0 0 5px white;\r\n        -moz-box-shadow: 0 0 20px #ff00aa, 0 0 5px white;\r\n        box-shadow: 0 0 20px #ff00aa, 0 0 5px white; }\r\n    .no-touch .deck-container.deck-menu .slide:hover {\r\n      background: #444444; }\r\n    .no-touch.boxshadow .deck-container.deck-menu .slide:hover {\r\n      background: black;\r\n      -webkit-box-shadow: 0 0 20px #ff00aa, 0 0 5px white;\r\n      -moz-box-shadow: 0 0 20px #ff00aa, 0 0 5px white;\r\n      box-shadow: 0 0 20px #ff00aa, 0 0 5px white; }\r\n\r\n\r\n', '2013-01-24 12:26:50', '', NULL),
(2, 1, 'Swiss', '', '.slide-footer{\r\n   z-index:999;\r\n   position:fixed;\r\n   left:0px;\r\n   bottom:0px;\r\n   height:30px;\r\n   width:100%;\r\n}\r\n	font-family: "Helvetica Neue", sans-serif;\r\n	font-size:1.25em;\r\n	background:#fff;\r\n	\r\n	.slide {\r\n		background:#fff;\r\n		\r\n		h1 {\r\n			color:#000;\r\n		}\r\n\r\n		h2 {\r\n			color:#c00;\r\n			border-bottom-color:#ccc;\r\n		}\r\n\r\n		h3 {\r\n			color:#888;\r\n		}\r\n\r\n		pre {\r\n			border-color:#ccc;\r\n		}\r\n\r\n		code {\r\n			color:#000; \r\n                        background-color: transparent;\r\n		}\r\n\r\n		blockquote {\r\n			font-size:2em;\r\n			font-style:italic;\r\n			padding:1em 2em;\r\n			color:#000;\r\n			border-left:5px solid #ccc;\r\n\r\n			p {\r\n				margin:0;\r\n			}\r\n\r\n			cite {\r\n				font-size:.5em;\r\n				font-style:normal;\r\n				font-weight:bold;\r\n				color:#888;\r\n			}\r\n		}\r\n\r\n		::-moz-selection{ background:#c00; color:#fff; }\r\n		::selection { background:#c00; color:#fff; }\r\n\r\n		a {\r\n			&, &:hover, &:focus, &:active, &:visited {\r\n				color:#c00;\r\n				text-decoration:none;\r\n			}\r\n\r\n			&:hover, &:focus {\r\n				text-decoration:underline;\r\n			}\r\n		}\r\n	}\r\n	\r\n	> .slide {\r\n		.deck-before, .deck-previous {\r\n			opacity:0.4;\r\n		}\r\n	} \r\n	\r\n	.deck-prev-link, .deck-next-link {\r\n		background:#ccc;\r\n		font-family:serif; // sans-serif arrows x-browser fail\r\n		\r\n		&, &:hover, &:focus, &:active, &:visited {\r\n			color:#fff;\r\n		}\r\n		\r\n		&:hover, &:focus {\r\n			background:#c00;\r\n			text-decoration:none;\r\n		}\r\n	}\r\n	\r\n	.deck-status {\r\n		font-size:0.6666em;\r\n	}\r\n	\r\n	&.deck-menu {\r\n		.slide {\r\n			background:#eee;\r\n		}\r\n		\r\n		.deck-current, .no-touch & .slide:hover {\r\n			background:#ddf;\r\n		}\r\n	}', '.deck-container {\r\n  font-family: "Helvetica Neue", sans-serif;\r\n  font-size: 1.25em;\r\n  background: white; }\r\n  .deck-container .slide-footer {\r\n    z-index: 999;\r\n    position: fixed;\r\n    left: 0px;\r\n    bottom: 0px;\r\n    height: 30px;\r\n    width: 100%; }\r\n  .deck-container .slide {\r\n    background: white; }\r\n    .deck-container .slide h1 {\r\n      color: black; }\r\n    .deck-container .slide h2 {\r\n      color: #cc0000;\r\n      border-bottom-color: #cccccc; }\r\n    .deck-container .slide h3 {\r\n      color: #888888; }\r\n    .deck-container .slide pre {\r\n      border-color: #cccccc; }\r\n    .deck-container .slide code {\r\n      color: black;\r\n      background-color: transparent; }\r\n    .deck-container .slide blockquote {\r\n      font-size: 2em;\r\n      font-style: italic;\r\n      padding: 1em 2em;\r\n      color: black;\r\n      border-left: 5px solid #cccccc; }\r\n      .deck-container .slide blockquote cite {\r\n        font-size: 0.5em;\r\n        font-style: normal;\r\n        font-weight: bold;\r\n        color: #888888; }\r\n    .deck-container .slide ::-moz-selection {\r\n      background: #cc0000;\r\n      color: white; }\r\n    .deck-container .slide ::selection {\r\n      background: #cc0000;\r\n      color: white; }\r\n      .deck-container .slide a,\r\n      .deck-container .slide a:active,\r\n      .deck-container .slide a:focus,\r\n      .deck-container .slide a:hover,\r\n      .deck-container .slide a:visited {\r\n        color: #cc0000;\r\n        text-decoration: none; }\r\n      .deck-container .slide a:focus,\r\n      .deck-container .slide a:hover {\r\n        text-decoration: underline; }\r\n    .deck-container > .slide .deck-before,\r\n    .deck-container > .slide .deck-previous {\r\n      opacity: 0.4; }\r\n  .deck-container .deck-next-link,\r\n  .deck-container .deck-prev-link {\r\n    background: #cccccc;\r\n    font-family: serif; }\r\n    .deck-container .deck-next-link,\r\n    .deck-container .deck-next-link:active,\r\n    .deck-container .deck-next-link:focus,\r\n    .deck-container .deck-next-link:hover,\r\n    .deck-container .deck-next-link:visited,\r\n    .deck-container .deck-prev-link,\r\n    .deck-container .deck-prev-link:active,\r\n    .deck-container .deck-prev-link:focus,\r\n    .deck-container .deck-prev-link:hover,\r\n    .deck-container .deck-prev-link:visited {\r\n      color: white; }\r\n    .deck-container .deck-next-link:focus,\r\n    .deck-container .deck-next-link:hover,\r\n    .deck-container .deck-prev-link:focus,\r\n    .deck-container .deck-prev-link:hover {\r\n      background: #cc0000;\r\n      text-decoration: none; }\r\n  .deck-container .deck-status {\r\n    font-size: 0.6666em; }\r\n    .deck-container.deck-menu .slide {\r\n      background: #eeeeee; }\r\n    .deck-container.deck-menu .deck-current,\r\n    .no-touch .deck-container.deck-menu .slide:hover {\r\n      background: #ddddff; }\r\n\r\n\r\n', '2013-01-24 12:21:18', '', NULL),
(1, 1, 'simple', '', '.first-slide{\r\n}\r\n.first-sub-slide{\r\n}\r\n.slide-header{\r\n\r\n}\r\n.slide-title{\r\n}\r\n.slide-body{\r\n}\r\n.slide-metadata{\r\n}\r\n.slide-footer{\r\n   z-index:999;\r\n   position:fixed;\r\n   left:0px;\r\n   bottom:0px;\r\n   height:30px;\r\n   width:100%;\r\n}\r\n.slide-footer-text{\r\n}\r\n.slide {\r\n		h1 {	font-size: 8;	\r\n		}\r\n\r\n		h2 {\r\n		}\r\n\r\n		h3 {\r\n		}\r\n\r\n		pre {\r\n		}\r\n\r\n		code {\r\n			color:#000; \r\n                        background-color: transparent;\r\n		}\r\n\r\n		blockquote {\r\n			p {\r\n			}\r\n\r\n			cite {\r\n\r\n			}\r\n		}\r\n		a {\r\n			&, &:hover, &:focus, &:active, &:visited {\r\n\r\n			}\r\n\r\n			&:hover, &:focus {\r\n			}\r\n		}\r\n	}\r\n	\r\n	> .slide {\r\n		.deck-before, .deck-previous {\r\n		}\r\n	} \r\n	\r\n	.deck-prev-link, .deck-next-link {\r\n		\r\n		&, &:hover, &:focus, &:active, &:visited {\r\n		}\r\n		\r\n		&:hover, &:focus {\r\n		}\r\n	}\r\n	\r\n	.deck-status {\r\n	}\r\n	\r\n	&.deck-menu {\r\n		.slide {\r\n		}\r\n		\r\n		.deck-current, .no-touch & .slide:hover {\r\n		}\r\n	}', '\r\n\r\n\r\n  .deck-container .slide-footer {\r\n    z-index: 999;\r\n    position: fixed;\r\n    left: 0px;\r\n    bottom: 0px;\r\n    height: 30px;\r\n    width: 100%; }\r\n\r\n    .deck-container .slide h1 {\r\n      font-size: 8; }\r\n\r\n    .deck-container .slide code {\r\n      color: black;\r\n      background-color: transparent; }\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n', '2013-01-24 15:57:46', '', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `subscription`
--

CREATE TABLE IF NOT EXISTS `subscription` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `item_type` enum('slide','deck','user') COLLATE utf8_unicode_ci NOT NULL,
  `item_id` int(10) unsigned NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `tag`
--

CREATE TABLE IF NOT EXISTS `tag` (
  `item_type` enum('slide','deck') COLLATE utf8_unicode_ci NOT NULL,
  `item_id` int(11) NOT NULL,
  `tag` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  KEY `item_type` (`item_type`,`item_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `tag`
--

INSERT INTO `tag` (`item_type`, `item_id`, `tag`) VALUES
('deck', 1, ''),
('deck', 2, ''),
('deck', 3, ''),
('deck', 4, ''),
('deck', 5, ''),
('deck', 6, ''),
('deck', 7, ''),
('deck', 8, ''),
('deck', 9, '');

-- --------------------------------------------------------

--
-- Table structure for table `testing`
--

CREATE TABLE IF NOT EXISTS `testing` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `attempt_id` int(11) DEFAULT '0',
  `user_id` int(11) NOT NULL,
  `item_id` int(11) NOT NULL,
  `title` text COLLATE utf8_unicode_ci NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `wiki_app` float DEFAULT NULL,
  `mtf` float DEFAULT NULL,
  `dich` float DEFAULT NULL,
  `morgan` float DEFAULT NULL,
  `ripkey` float DEFAULT NULL,
  `max_points` float DEFAULT NULL,
  `type` enum('auto','list','exam') COLLATE utf8_unicode_ci NOT NULL,
  `mode` tinyint(4) DEFAULT NULL,
  `limit` tinyint(4) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `test_content`
--

CREATE TABLE IF NOT EXISTS `test_content` (
  `test_id` int(11) NOT NULL,
  `question_id` int(11) NOT NULL,
  UNIQUE KEY `test_id` (`test_id`,`question_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `test_results`
--

CREATE TABLE IF NOT EXISTS `test_results` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `attempt_id` int(11) NOT NULL,
  `quest_id` int(11) NOT NULL,
  `checked` text CHARACTER SET utf8 COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `transition`
--

CREATE TABLE IF NOT EXISTS `transition` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `scss_varfunc` text COLLATE utf8_unicode_ci,
  `scss` text COLLATE utf8_unicode_ci,
  `css` text COLLATE utf8_unicode_ci NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `comment` text COLLATE utf8_unicode_ci,
  `based_on` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=7 ;

--
-- Dumping data for table `transition`
--

INSERT INTO `transition` (`id`, `user_id`, `name`, `scss_varfunc`, `scss`, `css`, `timestamp`, `comment`, `based_on`) VALUES
(1, 2, 'None', NULL, NULL, '', '2012-01-13 10:36:59', NULL, NULL),
(4, 2, 'Fade', '@mixin translate($x: 0, $y: 0, $z: 0) {\r\n	-webkit-transform:translate3d($x, $y, $z);\r\n	-moz-transform:translate($x, $y);\r\n	-ms-transform:translate($x, $y);\r\n	-o-transform:translate($x, $y);\r\n	transform:translate3d($x, $y, $z);\r\n}\r\n\r\n@mixin transition($prop, $duration, $easing: ease-in-out, $delay: 0ms) {\r\n	-webkit-transition:$prop $duration $easing $delay;\r\n	-moz-transition:$prop $duration $easing $delay;\r\n	-ms-transition:$prop $duration $easing $delay;\r\n	-o-transition:$prop $duration $easing $delay;\r\n	transition:$prop $duration $easing $delay;\r\n}', '	.deck-container .slide {\r\n		@include transition(opacity, 500ms);\r\n	}\r\n	\r\n	.deck-container:not(.deck-menu) {\r\n		> .slide {\r\n			position:absolute;\r\n			top:0;\r\n			left:0;\r\n			-webkit-box-sizing: border-box;\r\n			-moz-box-sizing: border-box;\r\n			box-sizing: border-box;\r\n			width:100%;\r\n			padding:0 48px;\r\n			\r\n			.slide {\r\n				position:relative;\r\n				left:0;\r\n				top:0;\r\n				opacity:0;\r\n			}\r\n			\r\n			.deck-current {\r\n				opacity:1;\r\n			}\r\n		}\r\n\r\n		> .deck-previous, > .deck-before, > .deck-next, > .deck-after {\r\n			opacity:0;\r\n			pointer-events:none;\r\n		}\r\n		\r\n		> .deck-before, > .deck-previous {\r\n			.slide {\r\n				visibility:visible;\r\n			}\r\n		}\r\n\r\n		> .deck-child-current {\r\n			opacity:1;\r\n			visibility:visible;\r\n			pointer-events:auto;\r\n			\r\n			.deck-next, .deck-after {\r\n				visibility:hidden;\r\n			}\r\n		}\r\n	}', '.csstransitions.csstransforms .deck-container .slide {\r\n  -webkit-transition: opacity 500ms ease-in-out 0ms;\r\n  -moz-transition: opacity 500ms ease-in-out 0ms;\r\n  -ms-transition: opacity 500ms ease-in-out 0ms;\r\n  -o-transition: opacity 500ms ease-in-out 0ms;\r\n  transition: opacity 500ms ease-in-out 0ms;\r\n}\r\n.csstransitions.csstransforms .deck-container:not(.deck-menu) > .slide {\r\n  position: absolute;\r\n  top: 0;\r\n  left: 0;\r\n  -webkit-box-sizing: border-box;\r\n  -moz-box-sizing: border-box;\r\n  box-sizing: border-box;\r\n  width: 100%;\r\n  padding: 0 48px;\r\n}\r\n.csstransitions.csstransforms .deck-container:not(.deck-menu) > .slide .slide {\r\n  position: relative;\r\n  left: 0;\r\n  top: 0;\r\n  opacity: 0;\r\n}\r\n.csstransitions.csstransforms .deck-container:not(.deck-menu) > .slide .deck-current {\r\n  opacity: 1;\r\n}\r\n.csstransitions.csstransforms .deck-container:not(.deck-menu) > .deck-previous, .csstransitions.csstransforms .deck-container:not(.deck-menu) > .deck-before, .csstransitions.csstransforms .deck-container:not(.deck-menu) > .deck-next, .csstransitions.csstransforms .deck-container:not(.deck-menu) > .deck-after {\r\n  opacity: 0;\r\n  pointer-events: none;\r\n}\r\n.csstransitions.csstransforms .deck-container:not(.deck-menu) > .deck-before .slide, .csstransitions.csstransforms .deck-container:not(.deck-menu) > .deck-previous .slide {\r\n  visibility: visible;\r\n}\r\n.csstransitions.csstransforms .deck-container:not(.deck-menu) > .deck-child-current {\r\n  opacity: 1;\r\n  visibility: visible;\r\n  pointer-events: auto;\r\n}\r\n.csstransitions.csstransforms .deck-container:not(.deck-menu) > .deck-child-current .deck-next, .csstransitions.csstransforms .deck-container:not(.deck-menu) > .deck-child-current .deck-after {\r\n  visibility: hidden;\r\n}', '2012-03-12 08:57:12', NULL, NULL),
(2, 2, 'Horizontal-slide', '@mixin translate($x: 0, $y: 0, $z: 0) {\r\n	-webkit-transform:translate3d($x, $y, $z);\r\n	-moz-transform:translate($x, $y);\r\n	-ms-transform:translate($x, $y);\r\n	-o-transform:translate($x, $y);\r\n	transform:translate3d($x, $y, $z);\r\n}\r\n\r\n@mixin transition($prop, $duration, $easing: ease-in-out, $delay: 0ms) {\r\n	-webkit-transition:$prop $duration $easing $delay;\r\n	-moz-transition:$prop $duration $easing $delay;\r\n	-ms-transition:$prop $duration $easing $delay;\r\n	-o-transition:$prop $duration $easing $delay;\r\n	transition:$prop $duration $easing $delay;\r\n}\r\n\r\n@mixin transform($val) {\r\n	-webkit-transform:$val;\r\n	-moz-transform:$val;\r\n	-ms-transform:$val;\r\n	-o-transform:$val;\r\n	transform:$val;\r\n}', '	overflow-x:hidden;\r\n	\r\n	.deck-container > .slide {\r\n		-webkit-transition:-webkit-transform 500ms ease-in-out;\r\n		-moz-transition:-moz-transform 500ms ease-in-out;\r\n		-ms-transition:-ms-transform 500ms ease-in-out;\r\n		-o-transition:-o-transform 500ms ease-in-out;\r\n		transition:transform 500ms ease-in-out;\r\n	}\r\n	\r\n	.deck-container:not(.deck-menu) {\r\n		> .slide {\r\n			position:absolute;\r\n			top:0;\r\n			left:0;\r\n			-webkit-box-sizing: border-box;\r\n			-moz-box-sizing: border-box;\r\n			box-sizing: border-box;\r\n			width:100%;\r\n			padding:0 48px;\r\n			\r\n			.slide {\r\n				position:relative;\r\n				left:0;\r\n				top:0;\r\n				-webkit-transition:-webkit-transform 500ms ease-in-out, opacity 500ms ease-in-out;\r\n				-moz-transition:-moz-transform 500ms ease-in-out, opacity 500ms ease-in-out;\r\n				-ms-transition:-ms-transform 500ms ease-in-out, opacity 500ms ease-in-out;\r\n				-o-transition:-o-transform 500ms ease-in-out, opacity 500ms ease-in-out;\r\n				transition:-webkit-transform 500ms ease-in-out, opacity 500ms ease-in-out;\r\n			}\r\n\r\n			.deck-next, .deck-after {\r\n				visibility:visible;\r\n				@include translate(200%);\r\n			}\r\n		}\r\n\r\n		> .deck-previous {\r\n			@include translate(-200%);\r\n		}\r\n\r\n		> .deck-before {\r\n			@include translate(-400%);\r\n		}\r\n\r\n		> .deck-next {\r\n			@include translate(200%);\r\n		}\r\n\r\n		> .deck-after {\r\n			@include translate(400%);\r\n		}\r\n		\r\n		> .deck-before, > .deck-previous {\r\n			.slide {\r\n				visibility:visible;\r\n			}\r\n		}\r\n\r\n		> .deck-child-current {\r\n			@include transform(none);\r\n		}\r\n	}', '.csstransitions.csstransforms {\r\n  overflow-x: hidden;\r\n}\r\n.csstransitions.csstransforms .deck-container > .slide {\r\n  -webkit-transition: -webkit-transform 500ms ease-in-out;\r\n  -moz-transition: -moz-transform 500ms ease-in-out;\r\n  -ms-transition: -ms-transform 500ms ease-in-out;\r\n  -o-transition: -o-transform 500ms ease-in-out;\r\n  transition: transform 500ms ease-in-out;\r\n}\r\n.csstransitions.csstransforms .deck-container:not(.deck-menu) > .slide {\r\n  position: absolute;\r\n  top: 0;\r\n  left: 0;\r\n  -webkit-box-sizing: border-box;\r\n  -moz-box-sizing: border-box;\r\n  box-sizing: border-box;\r\n  width: 100%;\r\n  padding: 0 48px;\r\n}\r\n.csstransitions.csstransforms .deck-container:not(.deck-menu) > .slide .slide {\r\n  position: relative;\r\n  left: 0;\r\n  top: 0;\r\n  -webkit-transition: -webkit-transform 500ms ease-in-out, opacity 500ms ease-in-out;\r\n  -moz-transition: -moz-transform 500ms ease-in-out, opacity 500ms ease-in-out;\r\n  -ms-transition: -ms-transform 500ms ease-in-out, opacity 500ms ease-in-out;\r\n  -o-transition: -o-transform 500ms ease-in-out, opacity 500ms ease-in-out;\r\n  transition: -webkit-transform 500ms ease-in-out, opacity 500ms ease-in-out;\r\n}\r\n.csstransitions.csstransforms .deck-container:not(.deck-menu) > .slide .deck-next, .csstransitions.csstransforms .deck-container:not(.deck-menu) > .slide .deck-after {\r\n  visibility: visible;\r\n  -webkit-transform: translate3d(200%, 0, 0);\r\n  -moz-transform: translate(200%, 0);\r\n  -ms-transform: translate(200%, 0);\r\n  -o-transform: translate(200%, 0);\r\n  transform: translate3d(200%, 0, 0);\r\n}\r\n.csstransitions.csstransforms .deck-container:not(.deck-menu) > .deck-previous {\r\n  -webkit-transform: translate3d(-200%, 0, 0);\r\n  -moz-transform: translate(-200%, 0);\r\n  -ms-transform: translate(-200%, 0);\r\n  -o-transform: translate(-200%, 0);\r\n  transform: translate3d(-200%, 0, 0);\r\n}\r\n.csstransitions.csstransforms .deck-container:not(.deck-menu) > .deck-before {\r\n  -webkit-transform: translate3d(-400%, 0, 0);\r\n  -moz-transform: translate(-400%, 0);\r\n  -ms-transform: translate(-400%, 0);\r\n  -o-transform: translate(-400%, 0);\r\n  transform: translate3d(-400%, 0, 0);\r\n}\r\n.csstransitions.csstransforms .deck-container:not(.deck-menu) > .deck-next {\r\n  -webkit-transform: translate3d(200%, 0, 0);\r\n  -moz-transform: translate(200%, 0);\r\n  -ms-transform: translate(200%, 0);\r\n  -o-transform: translate(200%, 0);\r\n  transform: translate3d(200%, 0, 0);\r\n}\r\n.csstransitions.csstransforms .deck-container:not(.deck-menu) > .deck-after {\r\n  -webkit-transform: translate3d(400%, 0, 0);\r\n  -moz-transform: translate(400%, 0);\r\n  -ms-transform: translate(400%, 0);\r\n  -o-transform: translate(400%, 0);\r\n  transform: translate3d(400%, 0, 0);\r\n}\r\n.csstransitions.csstransforms .deck-container:not(.deck-menu) > .deck-before .slide, .csstransitions.csstransforms .deck-container:not(.deck-menu) > .deck-previous .slide {\r\n  visibility: visible;\r\n}\r\n.csstransitions.csstransforms .deck-container:not(.deck-menu) > .deck-child-current {\r\n  -webkit-transform: none;\r\n  -moz-transform: none;\r\n  -ms-transform: none;\r\n  -o-transform: none;\r\n  transform: none;\r\n}', '2012-03-12 08:57:32', NULL, NULL),
(3, 2, 'Vertical-slide', '@mixin translate($x: 0, $y: 0, $z: 0) {\r\n	-webkit-transform:translate3d($x, $y, $z);\r\n	-moz-transform:translate($x, $y);\r\n	-ms-transform:translate($x, $y);\r\n	-o-transform:translate($x, $y);\r\n	transform:translate3d($x, $y, $z);\r\n}\r\n\r\n@mixin rotate($deg) {\r\n	-webkit-transform:rotate($deg);\r\n	-moz-transform:rotate($deg);\r\n	-ms-transform:rotate($deg);\r\n	-o-transform:rotate($deg);\r\n	transform:rotate($deg);\r\n}\r\n\r\n@mixin transition($prop, $duration, $easing: ease-in-out, $delay: 0ms) {\r\n	-webkit-transition:$prop $duration $easing $delay;\r\n	-moz-transition:$prop $duration $easing $delay;\r\n	-ms-transition:$prop $duration $easing $delay;\r\n	-o-transition:$prop $duration $easing $delay;\r\n	transition:$prop $duration $easing $delay;\r\n}\r\n\r\n@mixin transform($val) {\r\n	-webkit-transform:$val;\r\n	-moz-transform:$val;\r\n	-ms-transform:$val;\r\n	-o-transform:$val;\r\n	transform:$val;\r\n}', '	.deck-container {\r\n		overflow-y:hidden;\r\n		\r\n		> .slide {\r\n			-webkit-transition:-webkit-transform 500ms ease-in-out;\r\n			-moz-transition:-moz-transform 500ms ease-in-out;\r\n			-ms-transition:-ms-transform 500ms ease-in-out;\r\n			-o-transition:-o-transform 500ms ease-in-out;\r\n			transition:transform 500ms ease-in-out;\r\n		}\r\n	}\r\n	\r\n	.deck-container:not(.deck-menu) {\r\n		> .slide {\r\n			position:absolute;\r\n			top:0;\r\n			left:0;\r\n			-webkit-box-sizing: border-box;\r\n			-moz-box-sizing: border-box;\r\n			box-sizing: border-box;\r\n			width:100%;\r\n			padding:0 48px;\r\n			\r\n			.slide {\r\n				position:relative;\r\n				left:0;\r\n				top:0;\r\n				-webkit-transition:-webkit-transform 500ms ease-in-out, opacity 500ms ease-in-out;\r\n				-moz-transition:-moz-transform 500ms ease-in-out, opacity 500ms ease-in-out;\r\n				-ms-transition:-ms-transform 500ms ease-in-out, opacity 500ms ease-in-out;\r\n				-o-transition:-o-transform 500ms ease-in-out, opacity 500ms ease-in-out;\r\n				transition:-webkit-transform 500ms ease-in-out, opacity 500ms ease-in-out;\r\n			}\r\n\r\n			.deck-next, .deck-after {\r\n				visibility:visible;\r\n				@include translate(0, 1600px);\r\n			}\r\n		}\r\n\r\n		> .deck-previous {\r\n			@include translate(0, -200%);\r\n		}\r\n\r\n		> .deck-before {\r\n			@include translate(0, -400%);\r\n		}\r\n\r\n		> .deck-next {\r\n			@include translate(0, 200%);\r\n		}\r\n\r\n		> .deck-after {\r\n			@include translate(0, 400%);\r\n		}\r\n		\r\n		> .deck-before, > .deck-previous {\r\n			.slide {\r\n				visibility:visible;\r\n			}\r\n		}\r\n\r\n		> .deck-child-current {\r\n			@include transform(none);\r\n		}\r\n	}\r\n	\r\n	.deck-prev-link {\r\n		left:auto;\r\n		right:8px;\r\n		top:59px;\r\n		@include rotate(90deg);\r\n	}\r\n	\r\n	.deck-next-link {\r\n		top:99px;\r\n		@include rotate(90deg);\r\n	}', '.csstransitions.csstransforms .deck-container {\r\n  overflow-y: hidden;\r\n}\r\n.csstransitions.csstransforms .deck-container > .slide {\r\n  -webkit-transition: -webkit-transform 500ms ease-in-out;\r\n  -moz-transition: -moz-transform 500ms ease-in-out;\r\n  -ms-transition: -ms-transform 500ms ease-in-out;\r\n  -o-transition: -o-transform 500ms ease-in-out;\r\n  transition: transform 500ms ease-in-out;\r\n}\r\n.csstransitions.csstransforms .deck-container:not(.deck-menu) > .slide {\r\n  position: absolute;\r\n  top: 0;\r\n  left: 0;\r\n  -webkit-box-sizing: border-box;\r\n  -moz-box-sizing: border-box;\r\n  box-sizing: border-box;\r\n  width: 100%;\r\n  padding: 0 48px;\r\n}\r\n.csstransitions.csstransforms .deck-container:not(.deck-menu) > .slide .slide {\r\n  position: relative;\r\n  left: 0;\r\n  top: 0;\r\n  -webkit-transition: -webkit-transform 500ms ease-in-out, opacity 500ms ease-in-out;\r\n  -moz-transition: -moz-transform 500ms ease-in-out, opacity 500ms ease-in-out;\r\n  -ms-transition: -ms-transform 500ms ease-in-out, opacity 500ms ease-in-out;\r\n  -o-transition: -o-transform 500ms ease-in-out, opacity 500ms ease-in-out;\r\n  transition: -webkit-transform 500ms ease-in-out, opacity 500ms ease-in-out;\r\n}\r\n.csstransitions.csstransforms .deck-container:not(.deck-menu) > .slide .deck-next, .csstransitions.csstransforms .deck-container:not(.deck-menu) > .slide .deck-after {\r\n  visibility: visible;\r\n  -webkit-transform: translate3d(0, 1600px, 0);\r\n  -moz-transform: translate(0, 1600px);\r\n  -ms-transform: translate(0, 1600px);\r\n  -o-transform: translate(0, 1600px);\r\n  transform: translate3d(0, 1600px, 0);\r\n}\r\n.csstransitions.csstransforms .deck-container:not(.deck-menu) > .deck-previous {\r\n  -webkit-transform: translate3d(0, -200%, 0);\r\n  -moz-transform: translate(0, -200%);\r\n  -ms-transform: translate(0, -200%);\r\n  -o-transform: translate(0, -200%);\r\n  transform: translate3d(0, -200%, 0);\r\n}\r\n.csstransitions.csstransforms .deck-container:not(.deck-menu) > .deck-before {\r\n  -webkit-transform: translate3d(0, -400%, 0);\r\n  -moz-transform: translate(0, -400%);\r\n  -ms-transform: translate(0, -400%);\r\n  -o-transform: translate(0, -400%);\r\n  transform: translate3d(0, -400%, 0);\r\n}\r\n.csstransitions.csstransforms .deck-container:not(.deck-menu) > .deck-next {\r\n  -webkit-transform: translate3d(0, 200%, 0);\r\n  -moz-transform: translate(0, 200%);\r\n  -ms-transform: translate(0, 200%);\r\n  -o-transform: translate(0, 200%);\r\n  transform: translate3d(0, 200%, 0);\r\n}\r\n.csstransitions.csstransforms .deck-container:not(.deck-menu) > .deck-after {\r\n  -webkit-transform: translate3d(0, 400%, 0);\r\n  -moz-transform: translate(0, 400%);\r\n  -ms-transform: translate(0, 400%);\r\n  -o-transform: translate(0, 400%);\r\n  transform: translate3d(0, 400%, 0);\r\n}\r\n.csstransitions.csstransforms .deck-container:not(.deck-menu) > .deck-before .slide, .csstransitions.csstransforms .deck-container:not(.deck-menu) > .deck-previous .slide {\r\n  visibility: visible;\r\n}\r\n.csstransitions.csstransforms .deck-container:not(.deck-menu) > .deck-child-current {\r\n  -webkit-transform: none;\r\n  -moz-transform: none;\r\n  -ms-transform: none;\r\n  -o-transform: none;\r\n  transform: none;\r\n}\r\n.csstransitions.csstransforms .deck-prev-link {\r\n  left: auto;\r\n  right: 8px;\r\n  top: 59px;\r\n  -webkit-transform: rotate(90deg);\r\n  -moz-transform: rotate(90deg);\r\n  -ms-transform: rotate(90deg);\r\n  -o-transform: rotate(90deg);\r\n  transform: rotate(90deg);\r\n}\r\n.csstransitions.csstransforms .deck-next-link {\r\n  top: 99px;\r\n  -webkit-transform: rotate(90deg);\r\n  -moz-transform: rotate(90deg);\r\n  -ms-transform: rotate(90deg);\r\n  -o-transform: rotate(90deg);\r\n  transform: rotate(90deg);\r\n}', '2012-03-12 08:57:54', NULL, NULL),
(6, 2, 'Cube', '@mixin transition($prop, $duration, $easing: ease-in-out, $delay: 0ms) {\r\n	-webkit-transition:$prop $duration $easing $delay;\r\n	-moz-transition:$prop $duration $easing $delay;\r\n	-ms-transition:$prop $duration $easing $delay;\r\n	-o-transition:$prop $duration $easing $delay;\r\n	transition:$prop $duration $easing $delay;\r\n}\r\n\r\n@mixin transform($val) {\r\n	-webkit-transform:$val;\r\n	-moz-transform:$val;\r\n	-ms-transform:$val;\r\n	-o-transform:$val;\r\n	transform:$val;\r\n}\r\n\r\n@mixin perspective($val) {\r\n    -webkit-perspective:$val;\r\n    -moz-perspective:$val;\r\n    -ms-perspective:$val;\r\n    -o-perspective:$val;\r\n    perspective:$val;\r\n}', '.csstransitions.csstransforms {\r\n\r\n    @include perspective(1000);\r\n\r\n	.deck-container:not(.deck-menu) {\r\n	    overflow:hidden;\r\n\r\n		> .slide {\r\n			position:absolute;\r\n			top:0;\r\n			left:50%;\r\n			margin-left:-400px;\r\n			width:800px;\r\n            @include transition(all, 1s);\r\n            .slide{\r\n                @include transition(all, 1s);\r\n            }\r\n		}\r\n\r\n		> .deck-previous:not(.deck-child-current),\r\n		> .deck-before:not(.deck-child-current) {\r\n            @include transform(rotateY(   -90deg ) translateZ(400px) translateX(-400px));\r\n            opacity:0;\r\n	    }\r\n\r\n		.deck-next:not(.deck-child-current),\r\n		.deck-after:not(.deck-child-current) {\r\n            @include transform(rotateY(   90deg ) translateZ(400px) translateX(400px));\r\n            opacity:0;\r\n		}\r\n\r\n	}\r\n}\r\n', '.csstransitions.csstransforms {\r\n  -webkit-perspective: 1000;\r\n  -moz-perspective: 1000;\r\n  -ms-perspective: 1000;\r\n  -o-perspective: 1000;\r\n  perspective: 1000; }\r\n  .csstransitions.csstransforms .deck-container:not(.deck-menu) {\r\n    overflow: hidden; }\r\n    .csstransitions.csstransforms .deck-container:not(.deck-menu) > .slide {\r\n      position: absolute;\r\n      top: 0;\r\n      left: 50%;\r\n      margin-left: -400px;\r\n      width: 800px;\r\n      -webkit-transition: all 1s ease-in-out 0ms;\r\n      -moz-transition: all 1s ease-in-out 0ms;\r\n      -ms-transition: all 1s ease-in-out 0ms;\r\n      -o-transition: all 1s ease-in-out 0ms;\r\n      transition: all 1s ease-in-out 0ms; }\r\n      .csstransitions.csstransforms .deck-container:not(.deck-menu) > .slide .slide {\r\n        -webkit-transition: all 1s ease-in-out 0ms;\r\n        -moz-transition: all 1s ease-in-out 0ms;\r\n        -ms-transition: all 1s ease-in-out 0ms;\r\n        -o-transition: all 1s ease-in-out 0ms;\r\n        transition: all 1s ease-in-out 0ms; }\r\n    .csstransitions.csstransforms .deck-container:not(.deck-menu) > .deck-previous:not(.deck-child-current),\r\n    .csstransitions.csstransforms .deck-container:not(.deck-menu) > .deck-before:not(.deck-child-current) {\r\n      -webkit-transform: rotateY(-90deg) translateZ(400px) translateX(-400px);\r\n      -moz-transform: rotateY(-90deg) translateZ(400px) translateX(-400px);\r\n      -ms-transform: rotateY(-90deg) translateZ(400px) translateX(-400px);\r\n      -o-transform: rotateY(-90deg) translateZ(400px) translateX(-400px);\r\n      transform: rotateY(-90deg) translateZ(400px) translateX(-400px);\r\n      opacity: 0; }\r\n    .csstransitions.csstransforms .deck-container:not(.deck-menu) .deck-next:not(.deck-child-current),\r\n    .csstransitions.csstransforms .deck-container:not(.deck-menu) .deck-after:not(.deck-child-current) {\r\n      -webkit-transform: rotateY(90deg) translateZ(400px) translateX(400px);\r\n      -moz-transform: rotateY(90deg) translateZ(400px) translateX(400px);\r\n      -ms-transform: rotateY(90deg) translateZ(400px) translateX(400px);\r\n      -o-transform: rotateY(90deg) translateZ(400px) translateX(400px);\r\n      transform: rotateY(90deg) translateZ(400px) translateX(400px);\r\n      opacity: 0; }\r\n', '2012-04-20 13:38:46', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `translation_cronjobs`
--

CREATE TABLE IF NOT EXISTS `translation_cronjobs` (
  `revision_id` int(11) NOT NULL,
  `to_language` tinytext CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `future_deck` int(11) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `username` varchar(128) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `registered` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `default_theme` int(11) DEFAULT NULL,
  `fb_id` tinytext COLLATE utf8_unicode_ci,
  `first_name` tinytext COLLATE utf8_unicode_ci,
  `last_name` tinytext COLLATE utf8_unicode_ci,
  `gender` enum('male','female') COLLATE utf8_unicode_ci DEFAULT NULL,
  `locale` tinytext COLLATE utf8_unicode_ci,
  `hometown` tinytext COLLATE utf8_unicode_ci,
  `location` tinytext COLLATE utf8_unicode_ci,
  `languages` mediumtext COLLATE utf8_unicode_ci,
  `picture` tinytext COLLATE utf8_unicode_ci,
  `interests` mediumtext COLLATE utf8_unicode_ci,
  `description` mediumtext COLLATE utf8_unicode_ci,
  `birthday` varchar(11) COLLATE utf8_unicode_ci DEFAULT NULL,
  `infodeck` tinytext COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`),
  UNIQUE KEY `username` (`username`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=447 ;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `email`, `username`, `password`, `registered`, `default_theme`, `fb_id`, `first_name`, `last_name`, `gender`, `locale`, `hometown`, `location`, `languages`, `picture`, `interests`, `description`, `birthday`, `infodeck`) VALUES
(1, 'darya.tarasowa@gmail.com', 'vassilisha', '008aa8035a14437c3f11e0574c30ee7d', '2011-10-14 22:32:52', NULL, '100001382967482', 'Darya', 'Tarasova', 'female', 'ru_RU', 'Novosibirsk, Russia', 'Leipzig, Germany', NULL, 'https://graph.facebook.com/darya.tarassowa/picture?type=large', NULL, 'PhD Student at Agile Knowledge and Semantic Web research group, University of Leipzig, Germany', '12/24/1987', '');

-- --------------------------------------------------------

--
-- Table structure for table `user_group`
--

CREATE TABLE IF NOT EXISTS `user_group` (
  `deck_revision_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `category` enum('editor','viewer') NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `user_group`
--

INSERT INTO `user_group` (`deck_revision_id`, `user_id`, `category`, `timestamp`) VALUES
(4, 1, 'editor', '2013-08-29 17:48:00'),
(1, 1, 'editor', '2013-08-29 17:48:15'),
(2, 1, 'editor', '2013-08-29 17:48:27'),
(5, 1, 'editor', '2013-08-29 17:48:35'),
(6, 1, 'editor', '2013-08-29 17:48:48'),
(7, 1, 'editor', '2013-08-29 17:48:56'),
(3, 1, 'editor', '2013-08-29 17:49:06'),
(8, 1, 'editor', '2013-08-29 17:49:20');

-- --------------------------------------------------------

--
-- Table structure for table `user_tests`
--

CREATE TABLE IF NOT EXISTS `user_tests` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `title` text,
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
