<?php

	/*foreach ($presentation->_compare_table as $element) {
		
		if(!$element['slide_identical']) {
			//var_dump();
			echo 'Slide number ' . $element['old_slide']->id . ' has been changed!<br/>';
			echo 'The new slide id is ' . $element['new_slide']->id;
		}
	}*/
	
?>

<!-- Slide by slide comparison -->