<div class="content">
<div class="alert alert-block alert-error fade in">
<button class="close" data-dismiss="alert" type="button"></button>
<h1><img src="static/img/stop.png" /> Error!</h1><h3 class="alert-heading"> <?php echo $error_title?></h3>
<?php echo $error_response?>
</div>
<br /><br /><br /><br /><br />
<br /><br /><br /><br /><br />
</div>
