<header class="page-header">
	<h1>Test</h1>
</header>

<article>
<?php var_dump($rev->root_id); ?>
root changes: <?php echo $root_change;?>
</article>

<hr>


<footer>

</footer>