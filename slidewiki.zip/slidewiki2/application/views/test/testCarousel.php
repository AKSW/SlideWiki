 <link rel="stylesheet" href="static/css/carousel.css" type="text/css" media="all" />


<script type="text/javascript" src="libraries/frontend/jquery.roundabout.min.js"></script>
<script type="text/javascript" src="libraries/frontend/jquery.roundabout-shapes.min.js"></script>

<ul id="home_carousel">
	<li id="wysiwyg"><h2><a href="deck/159/latest">WYSIWYG slide authoring</a></h2><p>as asasasas ads.asfdsafasf.</p></li>
	<li id="logical"><h2><a href="slide/612/latest">Logical slide and deck representation</a></h2><p> asd adad adad.asas.</p></li>
	<li id="mathml"><h2><a href="slide/11610/latest">LaTeX/MathML integration</a></h2><p>as asasasas ads.asfdsafasf.</p></li>
	<li id="multilingual"><h2><a href="slide/9022/latest">Multilingual decks</a></h2><p>/ semi-automatic translation in 50+ languages</p></li>				
	<li id="import"><h2><a href="slide/9021/latest">PowerPoint/HTML import</a></h2><p>as asasasas ads.asfdsafasf.</p></li>
	<li id="sourcehighlighting"><h2><a href="slide/10971/latest">Source code highlighting within slides</a></h2><p>as asasasas ads.asfdsafasf.</p></li>
	<li id="theme"><h2><a href="slide/9662/latest">Dynamic CSS themability and transitions</a></h2><p>as asasasas ads.asfdsafasf.</p></li>
	<li id="socialnet"><h2><a href="slide/10973/latest">Support of social networking activities</a></h2><p>as asasasas ads.asfdsafasf.</p></li>
	<li id="revisioning"><h2><a href="deck/164/latest">Full revisioning and branching of presentations</a></h2><p>as asasasas ads.asfdsafasf.</p></li>
	<li id="elearning"><h2><a href="slide/9044/latest">E-Learning</a></h2><p>as asasasas ads.asfdsafasf.</p></li>
	<li id="remote"><h2><a href="slide/19231/latest">Remote control of presentations</a></h2><p>as asasasas ads.asfdsafasf.</p></li>
</ul> 

<script>
$(function(){
	$('#home_carousel').roundabout({
		minScale: 0.7,
		duration: 1600,
	    autoplay: true,
	    autoplayDuration: 3000,
	    autoplayPauseOnHover: true
	});
});
</script>


