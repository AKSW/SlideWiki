﻿<div class="content">
<header class="page-header">
	<h1>
		Imprint
	</h1>
</header>
<br /><a name="p27251-1"></a><p class="auto" id="p27251-1">
<strong>Agile Knowledge Engineering and Semantic Web (AKSW) Research Group</strong></p><br /><a name="p27251-2"></a><p class="auto" id="p27251-2">
Telefon: +49 341 <span class="nobr">97&ndash;323</span>10<br />
Telefax: +49 341 <span class="nobr">97&ndash;323</span>69<br />
Website: <img src="http://bis.informatik.uni-leipzig.de/themes/bis2007/icons/world_link.png" alt="" class="contexticon" /> <a href="http://aksw.org" target="_blank"> http://aksw.org</a><br />
E-Mail: <a href="mailto:aksw@informatik.uni-leipzig.de" target="_blank" title="Schreibe E-Mail (Mailprogramm wird gestartet)" class="outerlink"><img src="http://bis.informatik.uni-leipzig.de/themes/bis2007/icons/email.png" alt="" class="contexticon" /> aksw@informatik.uni-leipzig.de</a></p><br /><a name="p27251-3"></a><p class="auto" id="p27251-3">

<blockquote>
Leipzig University<br />
Faculty of Mathematics and Computer Science<br />
Institute of Computer Science<br />
Dept. Business Information Systems<br />
Augustusplatz 10<br />
04109 Leipzig, Germany
</blockquote></p><br /><a name="p27251-4"></a><p class="auto" id="p27251-4">
University of Leipzig is a public corporation. More information, especially concerning regulatory authorities can be found in the <a href="http://www.uni-leipzig.de/info/impressum.html" target="_blank" title="externer Verweis (in neuem Fenster)" class="outerlink"><img src="http://bis.informatik.uni-leipzig.de/themes/bis2007/icons/world_link.png" alt="" class="contexticon" /> imprint of the University of Leipzig</a>.</p><br /><a name="p27251-5"></a><p class="auto" id="p27251-5">

<!--notypo--><br />
</div>

