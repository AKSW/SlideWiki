<?php 
header("Location: ./");