<section>

	<textarea rows="2" cols="20">
		<?php echo $first_slide_content ?>
	</textarea>
	
	<textarea rows="2" cols="20">
		<?php echo $second_slide_content ?>
	</textarea>
	
	<textarea rows="2" cols="20">
		<?php echo $comparison_result ?>
	</textarea>

</section>