<div class="content">
<div  class="alert alert-block alert-<?php echo $type;?> fade in" data-alert="alert">
<?php echo $response;?>
</div>
 </div>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>