<?php

/** Configuration Variables **/
// enable error reporting
define ('DEVELOPMENT_ENVIRONMENT',true);

// db stuff
define('DB_DSN', 'mysql:dbname=slidewiki;host=localhost;charset=utf8');
define('DB_NAME', 'slidewiki');
define('DB_USER', 'slidewiki');
define('DB_PASSWORD', 'sw123');
//base path for mode rewrite
define('BASE_PATH', 'http://localhost/slidewiki2/');
//facebook-API (slidewiki.aksw.org)
define('FB_APP','318011144965910');
define('FB_SECRET','31405843d64604ce717f2464a2c3b063');
define('FB_URL','http://slidewiki.aksw.org/facebook/login');


