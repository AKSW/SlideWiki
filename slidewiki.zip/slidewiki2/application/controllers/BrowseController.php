<?php

class BrowseController extends Controller {
	function usage() {
	}
}
