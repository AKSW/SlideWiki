<?php

require_once (ROOT . DS . 'application' . DS . 'config' . DS . 'config.php');
require_once (ROOT . DS . 'application' . DS . 'library' . DS . 'shared.php');


